"""
CampusFlow AI - Comprehensive Test Suite for Event Planner Agent
Tests all 12 core functional domains plus the end-to-end Demo Test Case.
"""

import os
import sys
import json
import unittest
import tempfile
import shutil

# Include source paths
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'agents'))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'models'))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'services'))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'storage'))

from planner_agent import EventPlannerAgent
from services.ai_service import AIService
from storage.repository import EventRepository
from server import app


class TestEventPlannerAgent(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.temp_db_path = os.path.join(self.temp_dir, "test_campus_data.json")
        
        # Seed test data
        seed_data = {
            "events": [{"id": "evt-001", "name": "Initial Test Event", "expectedParticipants": 100}],
            "tasks": [],
            "approvals": [],
            "agentRuns": [],
            "eventPlans": {},
            "eventRequirements": {}
        }
        with open(self.temp_db_path, "w", encoding="utf-8") as f:
            json.dump(seed_data, f)
            
        self.repo = EventRepository(self.temp_db_path)
        self.agent = EventPlannerAgent()
        self.client = app.test_client()

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    # -------------------------------------------------------------------------
    # 1. Natural Language Requirement Extraction
    # -------------------------------------------------------------------------
    def test_01_natural_language_extraction(self):
        prompt = "Plan a 2-day AI Hackathon for 150 students on September 12 and 13 with auditorium, Wi-Fi, and 6 projectors."
        result = self.agent.plan_event({"prompt": prompt})
        self.assertTrue(result["success"])
        overview = result["plan"]["eventOverview"]
        self.assertEqual(overview["type"], "hackathon")
        self.assertEqual(overview["expectedParticipants"], 150)
        self.assertEqual(overview["durationDays"], 2)
        
        equip_types = [e["type"] for e in result["plan"]["equipmentRequirements"]]
        self.assertIn("projector", equip_types)
        self.assertIn("wifi", equip_types)

    # -------------------------------------------------------------------------
    # 2. Structured Input Support
    # -------------------------------------------------------------------------
    def test_02_structured_input(self):
        structured = {
            "name": "Robotics Workshop 2026",
            "eventType": "workshop",
            "startDate": "2026-10-10",
            "endDate": "2026-10-10",
            "expectedParticipants": 60,
            "requirements": ["auditorium", "projectors", "wifi", "volunteers"]
        }
        result = self.agent.plan_event(structured)
        self.assertTrue(result["success"])
        self.assertEqual(result["event"]["name"], "Robotics Workshop 2026")
        self.assertEqual(result["event"]["type"], "workshop")
        self.assertEqual(result["event"]["expectedParticipants"], 60)

    # -------------------------------------------------------------------------
    # 3. Missing Information Detection
    # -------------------------------------------------------------------------
    def test_03_missing_information_detection(self):
        # Prompt with missing dates and venue
        vague_prompt = "Plan a hackathon for 150 students."
        result = self.agent.plan_event({"prompt": vague_prompt})
        self.assertTrue(result["success"])
        missing = result["analysis"]["missingInformation"]
        self.assertIn("startDate", missing["required"])
        self.assertIn("endDate", missing["required"])
        # Generated plan continues with reasonable assumptions
        self.assertGreater(len(result["analysis"]["assumptions"]), 0)

    # -------------------------------------------------------------------------
    # 4. Date Validation
    # -------------------------------------------------------------------------
    def test_04_date_validation_error(self):
        invalid_data = {
            "name": "Invalid Date Fest",
            "startDate": "2026-09-20",
            "endDate": "2026-09-10",  # End before start!
            "expectedParticipants": 100
        }
        is_valid, errors, _ = self.agent.validate_input(invalid_data)
        self.assertFalse(is_valid)
        self.assertTrue(any("cannot be after" in e for e in errors))

    # -------------------------------------------------------------------------
    # 5. Participant Count Validation
    # -------------------------------------------------------------------------
    def test_05_participant_validation(self):
        invalid_part = {
            "name": "Zero Participant Conference",
            "expectedParticipants": -5
        }
        is_valid, errors, _ = self.agent.validate_input(invalid_part)
        self.assertFalse(is_valid)
        self.assertTrue(any("positive" in e for e in errors))

    # -------------------------------------------------------------------------
    # 6. Event Plan Generation
    # -------------------------------------------------------------------------
    def test_06_event_plan_generation(self):
        prompt = "Organize a Technical Fest for 300 participants."
        result = self.agent.plan_event({"prompt": prompt})
        self.assertTrue(result["success"])
        self.assertIn("plan", result)
        plan = result["plan"]
        self.assertIn("schedule", plan)
        self.assertIn("tasks", plan)
        self.assertIn("constraints", plan)
        self.assertIn("assumptions", plan)

    # -------------------------------------------------------------------------
    # 7. Task Generation & Priority Calculation
    # -------------------------------------------------------------------------
    def test_07_task_generation_and_priorities(self):
        prompt = "Organize an overnight AI Hackathon for 150 students with security and Wi-Fi."
        result = self.agent.plan_event({"prompt": prompt})
        tasks = result["plan"]["tasks"]
        self.assertGreaterEqual(len(tasks), 5)
        
        priorities = {t["priority"] for t in tasks}
        self.assertIn("critical", priorities)
        self.assertIn("high", priorities)
        
        # Security/Overnight task should be critical
        sec_tasks = [t for t in tasks if t["category"] == "security"]
        self.assertTrue(any(t["priority"] == "critical" for t in sec_tasks))

    # -------------------------------------------------------------------------
    # 8. Constraint Detection
    # -------------------------------------------------------------------------
    def test_08_constraint_detection(self):
        prompt = "Plan a 2-day hackathon for 250 students with Wi-Fi."
        result = self.agent.plan_event({"prompt": prompt})
        constraints = result["plan"]["constraints"]
        c_types = [c["type"] for c in constraints]
        self.assertIn("capacity", c_types)
        self.assertIn("time", c_types)
        self.assertIn("resource", c_types)

    # -------------------------------------------------------------------------
    # 9. Fallback Mode & AI Service Degradation
    # -------------------------------------------------------------------------
    def test_09_fallback_mode(self):
        ai_service = AIService()
        # Force fallback by generating with no external keys
        extraction, source, conf, notice = ai_service.generate_structured_output("Organize a workshop for 50 students with 2 projectors.")
        self.assertEqual(source, "Deterministic Fallback Engine")
        self.assertEqual(extraction["event"]["type"], "workshop")
        self.assertEqual(extraction["event"]["expectedParticipants"], 50)
        self.assertGreaterEqual(conf, 0.9)

    # -------------------------------------------------------------------------
    # 10. Dynamic Replanning Logic
    # -------------------------------------------------------------------------
    def test_10_replanning(self):
        replan_res = self.agent.replan("evt-001", "The main auditorium is no longer available")
        self.assertTrue(replan_res["success"])
        self.assertTrue(replan_res["replanningRequired"])
        self.assertIn("venue", replan_res["affectedAreas"])
        self.assertIn("schedule", replan_res["affectedAreas"])
        self.assertIn("equipment", replan_res["affectedAreas"])

    # -------------------------------------------------------------------------
    # 11. Database Persistence
    # -------------------------------------------------------------------------
    def test_11_database_persistence(self):
        event_data = {
            "id": "evt-test-99",
            "name": "Persisted Event Test",
            "expectedParticipants": 200
        }
        self.repo.save_event(event_data)
        saved = self.repo.get_event("evt-test-99")
        self.assertIsNotNone(saved)
        self.assertEqual(saved["name"], "Persisted Event Test")

        # Test plan persistence
        plan_data = {"id": "plan-99", "status": "preliminary", "readinessScore": 90}
        self.repo.save_event_plan("evt-test-99", plan_data)
        saved_plan = self.repo.get_event_plan("evt-test-99")
        self.assertEqual(saved_plan["readinessScore"], 90)

    # -------------------------------------------------------------------------
    # 12. REST API Response Format & Endpoints
    # -------------------------------------------------------------------------
    def test_12_api_endpoints(self):
        # Test POST /api/events/plan with valid prompt
        resp = self.client.post('/api/events/plan', json={
            "prompt": "Plan a 2-day hackathon for 150 students on September 12 and 13."
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertTrue(data["success"])
        self.assertEqual(data["agent"]["name"], "EventPlannerAgent")
        self.assertIn("event", data)
        self.assertIn("plan", data)
        self.assertIn("analysis", data)

        # Test POST /api/events/plan with empty body (Expect 400)
        bad_resp = self.client.post('/api/events/plan', json={})
        self.assertEqual(bad_resp.status_code, 400)

        # Test GET /api/events/evt-001/plan
        plan_resp = self.client.get('/api/events/evt-001/plan')
        self.assertEqual(plan_resp.status_code, 200)

        # Test POST /api/events/evt-001/replan
        replan_resp = self.client.post('/api/events/evt-001/replan', json={
            "change": "The main auditorium is no longer available"
        })
        self.assertEqual(replan_resp.status_code, 200)
        replan_data = replan_resp.get_json()
        self.assertTrue(replan_data["replanningRequired"])

        # Test GET /api/events/evt-001/agent-runs
        runs_resp = self.client.get('/api/events/evt-001/agent-runs')
        self.assertEqual(runs_resp.status_code, 200)

    # -------------------------------------------------------------------------
    # 13. EXACT DEMO TEST CASE (Section 28 of prompt)
    # -------------------------------------------------------------------------
    def test_13_exact_demo_test_case(self):
        demo_prompt = (
            "Organize a 2-day AI Hackathon for 150 students on September 12 and 13. "
            "We need an auditorium, 5 computer labs, 6 projectors, Wi-Fi, 20 mentors, "
            "15 volunteers, food, registration desks and security. "
            "The event will run from 9 AM to 9 PM."
        )

        resp = self.client.post('/api/events/plan', json={"prompt": demo_prompt})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertTrue(data["success"])

        plan = data["plan"]
        overview = plan["eventOverview"]
        
        # Verify extraction:
        # Event type: hackathon
        self.assertEqual(overview["type"], "hackathon")
        # Duration: 2 days
        self.assertEqual(overview["durationDays"], 2)
        # Participants: 150
        self.assertEqual(overview["expectedParticipants"], 150)
        
        # Venues: auditorium and 5 computer labs
        venues = plan["venueRequirements"]
        v_types = [v["type"] for v in venues]
        self.assertIn("auditorium", v_types)
        self.assertIn("computer_lab", v_types)
        labs = next((v for v in venues if v["type"] == "computer_lab"), None)
        self.assertIsNotNone(labs)
        self.assertEqual(labs.get("numberOfRooms"), 5)

        # Equipment: 6 projectors, Wi-Fi
        equip = plan["equipmentRequirements"]
        proj = next((e for e in equip if e["type"] == "projector"), None)
        self.assertIsNotNone(proj)
        self.assertEqual(proj.get("quantity"), 6)
        
        wifi = next((e for e in equip if e["type"] == "wifi"), None)
        self.assertIsNotNone(wifi)

        # Staffing: 20 mentors, 15 volunteers
        staff = plan["staffingRequirements"]
        mentors = next((s for s in staff if s["role"] == "mentor"), None)
        self.assertIsNotNone(mentors)
        self.assertEqual(mentors.get("quantity"), 20)

        vols = next((s for s in staff if s["role"] == "volunteer"), None)
        self.assertIsNotNone(vols)
        self.assertEqual(vols.get("quantity"), 15)

        # Services: Food, Registration, Security
        services = plan["serviceRequirements"]
        s_types = [s["type"] for s in services]
        self.assertIn("catering", s_types)
        self.assertIn("registration", s_types)
        self.assertIn("security", s_types)

        # Working hours: 09:00 - 21:00 / 9 AM to 9 PM
        self.assertIn("9 AM - 9 PM", overview.get("workingHours", ""))

        # Plan components verification:
        self.assertGreater(len(plan["schedule"]), 0)
        self.assertGreater(len(plan["tasks"]), 0)
        self.assertGreater(len(plan["constraints"]), 0)
        self.assertGreater(len(plan["assumptions"]), 0)
        self.assertIn("missingInformation", data["analysis"])
        self.assertTrue(data["analysis"]["requiresHumanApproval"])


if __name__ == '__main__':
    unittest.main()
