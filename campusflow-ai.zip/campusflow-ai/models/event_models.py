"""
CampusFlow AI - Event Models & Data Definitions
Defines core data structures for Events, Requirements, Plans, Tasks, Agent Runs, and PlannerOutput.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
import datetime
import uuid

@dataclass
class Event:
    id: str
    name: str
    description: str = ""
    eventType: str = "general"
    startDate: Optional[str] = None
    endDate: Optional[str] = None
    expectedParticipants: int = 0
    status: str = "In Planning"  # In Planning, Scheduled, In Progress, Completed, Cancelled
    createdAt: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    updatedAt: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EventRequirement:
    id: str
    eventId: str
    category: str  # venue, equipment, staffing, service, special
    requirement: str
    quantity: int = 1
    priority: str = "medium"  # critical, high, medium, low
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EventPlan:
    id: str
    eventId: str
    planData: Dict[str, Any]
    readinessScore: int = 80
    status: str = "preliminary"  # preliminary, approved, active, archived
    createdAt: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    updatedAt: str = field(default_factory=lambda: datetime.datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EventTask:
    id: str
    eventId: str
    title: str
    description: str = ""
    category: str = "general"  # venue, equipment, staffing, security, catering, logistics
    priority: str = "medium"  # critical, high, medium, low
    status: str = "pending"  # pending, in_progress, completed, blocked
    deadline: Optional[str] = None
    assignedTo: str = "Unassigned"
    dependencies: List[str] = field(default_factory=list)
    requiresHumanApproval: bool = False
    approvalType: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AgentRun:
    id: str
    eventId: str
    agentName: str
    status: str  # pending, running, completed, failed
    input: Any
    output: Any
    startedAt: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    completedAt: Optional[str] = None
    duration: str = "0ms"
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PlannerOutput:
    """
    Standard interface passed from EventPlannerAgent to downstream agents:
    - VenueAgent
    - ResourceAgent
    - VolunteerAgent
    - ScheduleAgent
    - ConflictDetectionAgent
    """
    event: Dict[str, Any]
    venueRequirements: List[Dict[str, Any]]
    equipmentRequirements: List[Dict[str, Any]]
    staffingRequirements: List[Dict[str, Any]]
    serviceRequirements: List[Dict[str, Any]]
    schedule: List[Dict[str, Any]]
    tasks: List[Dict[str, Any]]
    constraints: List[Dict[str, Any]]
    assumptions: List[str]
    missingInformation: Dict[str, List[str]]
    humanApprovalRequirements: List[Dict[str, Any]]
    confidence: float = 0.95
    source: str = "AI Engine"  # AI Engine or Fallback Engine

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
