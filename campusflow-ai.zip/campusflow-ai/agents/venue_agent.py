class VenueAgent:
    """
    Venue Agent:
    - Analyzes campus venue capacities and facilities
    - Verifies date/time availability against existing bookings
    - Matches event footprint with best venue combo
    - Provides alternatives if primary space has constraints
    """
    def __init__(self, venues_data):
        self.name = "Venue Agent"
        self.role = "Venue Discovery, Capacity Matching & Spatial Allocation"
        self.venues_data = venues_data

    def evaluate_venues(self, event_spec):
        participants = event_spec.get("participants", 150)
        event_type = event_spec.get("eventType", "Hackathon")
        
        results = {
            "primaryVenue": None,
            "secondaryVenues": [],
            "alternatives": [],
            "venueEvaluations": [],
            "reasoning": "",
            "status": "Success"
        }

        # Check all venues
        for v in self.venues_data:
            has_capacity = v["capacity"] >= participants
            is_avail = v["status"] == "Available"
            
            fit_score = 0
            if has_capacity:
                fit_score += 50
            else:
                # Still useful as breakout/secondary space
                fit_score += 20
                
            if is_avail:
                fit_score += 40
            else:
                fit_score -= 20
                
            if "Projectors" in " ".join(v["facilities"]):
                fit_score += 5
            if "Wi-Fi" in " ".join(v["facilities"]):
                fit_score += 5

            eval_item = {
                "id": v["id"],
                "name": v["name"],
                "capacity": v["capacity"],
                "status": v["status"],
                "building": v["building"],
                "facilities": v["facilities"],
                "currentBooking": v["currentBooking"],
                "fitScore": fit_score,
                "recommendation": "Optimal" if fit_score >= 80 else ("Viable Breakout" if fit_score >= 60 else "Conflict/Busy")
            }
            results["venueEvaluations"].append(eval_item)

        # Sort by fit
        sorted_venues = sorted(results["venueEvaluations"], key=lambda x: x["fitScore"], reverse=True)
        
        # Primary selection
        results["primaryVenue"] = sorted_venues[0]
        
        # Secondary / breakout rooms
        if "Hackathon" in event_type or "Technical" in event_type:
            results["secondaryVenues"] = [v for v in sorted_venues[1:4] if v["status"] == "Available"]
        else:
            results["secondaryVenues"] = [sorted_venues[1]] if len(sorted_venues) > 1 else []

        # Alternatives
        results["alternatives"] = [
            {
                "name": "Innovation Lab + Seminar Hall A (Split Cohort)",
                "combinedCapacity": 200,
                "reason": "Reduces auditorium acoustic fatigue; dedicated hardware testbenches available."
            },
            {
                "name": "Block C High-Tech Auditorium",
                "combinedCapacity": 400,
                "reason": "Available if main block undergoes scheduled air-conditioner overhaul."
            }
        ]

        results["reasoning"] = (
            f"Venue Agent evaluated 7 campus venues for {participants} participants. "
            f"Locked '{results['primaryVenue']['name']}' (Capacity: {results['primaryVenue']['capacity']}, Status: Available). "
            f"Assigned {len(results['secondaryVenues'])} breakout labs for intensive coding/workshop tracks."
        )

        return results
