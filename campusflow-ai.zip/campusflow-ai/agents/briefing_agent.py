class StakeholderBriefingAgent:
    """
    Stakeholder Briefing Agent:
    - Generates role-tailored operational briefing packages for:
      1. Event Organizer
      2. Volunteer Workforce
      3. Campus Security Team
      4. Technical & AV Operations Crew
    - Provides formatted markdown and export-ready outputs.
    """
    def __init__(self):
        self.name = "Stakeholder Briefing Agent"
        self.role = "Context-Aware Persona Briefing & Dossier Generation"

    def generate_briefings(self, event_data, state_data):
        title = event_data.get("title", "AI Hackathon 2026")
        dates = event_data.get("date", "September 12 - 13, 2026")
        participants = event_data.get("expectedParticipants", 150)
        venue = event_data.get("primaryVenue", "Main Auditorium")

        briefings = {
            "organizer": {
                "title": "Executive Briefing: Event Operations",
                "targetPersona": "Lead Event Organizer / Faculty Advisor",
                "badge": "Leadership & Strategy",
                "keyHighlights": [
                    f"Overall Event Readiness: {state_data.get('readiness', {}).get('overallScore', 87)}%",
                    f"Venues Locked: {venue} + Computer Labs 1 & 2",
                    f"Volunteers Assigned: 12 Active Students across 7 Stations",
                    "Budget Sanction: Pending Emergency $450 backup rental approval"
                ],
                "criticalActionItems": [
                    "Approve Overnight Security Permit with Dean's signature by Sep 10, 17:00.",
                    "Verify catering delivery window for Sep 12 midnight pizza shipment.",
                    "Attend Pre-Event Dry Run at Main Auditorium on Sep 11 at 16:00."
                ],
                "riskAssessment": "Low-to-Moderate. Main risk is projector resource contention which has a recommended spare unit PRJ-07."
            },
            "volunteers": {
                "title": "Volunteer Operations Run-Sheet & Duty Stationing",
                "targetPersona": "Student Volunteer Workforce (12 Members)",
                "badge": "Field Execution",
                "keyHighlights": [
                    "Reporting Call Time: Day 1 (Sep 12) strictly at 07:45 AM at Main Foyer.",
                    "Dress Code: CampusFlow AI Volunteer Lanyards & Blue Event Tees.",
                    "Meal Tokens: Distributed by Sameer Khan at Dining Courtyard."
                ],
                "stationRoster": [
                    {"name": "Priya Sundaram", "role": "Registration Lead", "station": "Campus Foyer Entry Lane 1", "time": "08:00 - 11:30"},
                    {"name": "Aarav Sharma", "role": "Stage & AV Lead", "station": "Main Auditorium Stage Deck", "time": "08:00 - 18:00"},
                    {"name": "Rohan Deshmukh", "role": "Network & Power Lead", "station": "NOC / IT Labs 1 & 2", "time": "08:30 - Overnight"},
                    {"name": "Ananya Mukherjee", "role": "VIP & Mentor Liaison", "station": "Faculty Lounge", "time": "09:00 - 19:00"},
                    {"name": "Vikram Rathore", "role": "Night Security Lead", "station": "Gate 1 & Perimeter Patrol", "time": "20:00 - 08:00"}
                ],
                "instructions": "All volunteers must download the CampusFlow discord app for real-time task alerts and paging."
            },
            "security": {
                "title": "Campus Security & Safety Operational Dossier",
                "targetPersona": "Chief Security Officer & Night Patrol Guards",
                "badge": "Safety & Compliance",
                "keyHighlights": [
                    f"Expected Footfall: {participants} Students + 20 Corporate Mentors + 15 Staff.",
                    "Overnight Window: Sep 12 (22:00) to Sep 13 (06:00).",
                    "Active Zones: Admin Block Auditorium, Ground Floor Restrooms, IT Block Labs 1 & 2."
                ],
                "securityProtocols": [
                    "Enforce strict QR badge scanning at Gate 1; no unauthorized external visitors after 22:00.",
                    "Keep Gate 3 open exclusively for authorized catering & medical emergency vehicles.",
                    "Hourly physical patrol checks through computer lab corridors.",
                    "Emergency Paramedic Station: Campus Ambulance on standby at Gate 3."
                ],
                "emergencyContacts": [
                    {"role": "Chief Security Officer", "name": "Col. R. K. Nair", "phone": "+91 94440 12345"},
                    {"role": "Campus Medical Officer", "name": "Dr. S. Bannerjee", "phone": "+91 94440 67890"},
                    {"role": "Student Security Lead", "name": "Vikram Rathore", "phone": "+91 98765 43216"}
                ]
            },
            "technical": {
                "title": "Technical, Network & AV Infrastructure Plan",
                "targetPersona": "AV Specialists, Network Admins & Lab Techs",
                "badge": "Infrastructure & Systems",
                "keyHighlights": [
                    "Dedicated Event SSID: 'CampusFlow_AI_Hack' with 1Gbps symmetrical uplink.",
                    "Power Redundancy: 65 kVA Diesel Generator on auto-transfer standby.",
                    "Audio/Visual: Dual 4K Laser Projectors + 8 Shure Wireless Mics in Auditorium."
                ],
                "setupChecklist": [
                    {"item": "Deploy 5x Wi-Fi 6 Mesh access points across hacker bays", "owner": "Rohan D.", "status": "Ready"},
                    {"item": "Load test 35 industrial surge extension boards across 3 phases", "owner": "Aarav S.", "status": "Pending"},
                    {"item": "Configure HDMI matrix switcher for dual stage presenter screens", "owner": "Kavya I.", "status": "Ready"},
                    {"item": "Verify GitHub and HuggingFace API whitelist on campus firewall", "owner": "Meera N.", "status": "Ready"}
                ],
                "contingencyPlan": "If Primary Projector PRJ-04 fails, spare unit PRJ-07 is pre-staged on Standby Rack B."
            }
        }

        return briefings
