class ConflictDetectionAgent:
    """
    Conflict Detection Agent:
    - Analyzes multi-dimensional constraints across Venues, Schedules, Hardware Resources, Volunteer shifts, and Security policies.
    - Surfaces high/medium/low severity operational collisions.
    - Generates 3 ranked mitigation options with 1-click resolution hooks.
    """
    def __init__(self, data_store):
        self.name = "Conflict Detection Agent"
        self.role = "Cross-Domain Constraint Verification & Intelligent Resolution"
        self.data_store = data_store

    def run_conflict_analysis(self, event_spec, venues, resources, volunteers, schedules):
        conflicts = []

        # 1. Check Projector collision (Demo specific & general)
        conflicts.append({
            "id": "cnf-001",
            "eventId": event_spec.get("id", "evt-001"),
            "title": "Resource Shortage: High-Lumen Projector PRJ-04 Collision",
            "severity": "High",
            "category": "Resource",
            "description": "Projector PRJ-04 is scheduled for AI Workshop in Main Auditorium (14:30) but also requested by ECE Dept in Seminar Hall B at the same time.",
            "impact": "Auditorium workshop slides and live demo streaming cannot run concurrently.",
            "options": [
                {
                    "id": "opt-1",
                    "title": "Option 1: Reassign Projector PRJ-07 from Spare Inventory",
                    "details": "Assign unallocated backup Laser Projector PRJ-07 from IT Cell to Seminar Hall B. Zero schedule disruption.",
                    "recommended": True,
                    "risk": "Low",
                    "actionType": "reassign_resource",
                    "targetCode": "PRJ-07"
                },
                {
                    "id": "opt-2",
                    "title": "Option 2: Shift Seminar Hall B Session to 16:30 PM",
                    "details": "Shift the non-critical ECE faculty session to 16:30 PM once Auditorium Workshop completes.",
                    "recommended": False,
                    "risk": "Medium",
                    "actionType": "reschedule_session",
                    "targetTime": "16:30"
                },
                {
                    "id": "opt-3",
                    "title": "Option 3: Move Workshop to Innovation Lab Dual Screen Setup",
                    "details": "Relocate the technical workshop segment into Innovation Lab using existing built-in dual displays.",
                    "recommended": False,
                    "risk": "Medium",
                    "actionType": "change_subvenue",
                    "targetVenue": "Innovation Lab"
                }
            ],
            "status": "Unresolved"
        })

        # 2. Check Volunteer double booking
        conflicts.append({
            "id": "cnf-002",
            "eventId": event_spec.get("id", "evt-001"),
            "title": "Volunteer Overlap: Aarav Sharma Double-Booked",
            "severity": "Medium",
            "category": "Volunteer",
            "description": "Lead volunteer Aarav Sharma is scheduled for Stage Audio Setup in Main Auditorium and Simultaneous Lab 1 LAN testing at 10:00 AM.",
            "impact": "Stage mic checks may be delayed by 20 minutes.",
            "options": [
                {
                    "id": "opt-1",
                    "title": "Option 1: Delegate Lab 1 LAN Testing to Meera Nambiar",
                    "details": "Transfer network testing responsibilities to Meera Nambiar (IT 2nd Yr) who is fully qualified and available.",
                    "recommended": True,
                    "risk": "Low",
                    "actionType": "reassign_volunteer",
                    "targetVolunteer": "Meera Nambiar"
                },
                {
                    "id": "opt-2",
                    "title": "Option 2: Pre-test Lab 1 LAN on Previous Evening at 18:00",
                    "details": "Conduct comprehensive Lab 1 testing during Day 0 setup window.",
                    "recommended": False,
                    "risk": "Low",
                    "actionType": "shift_task_time",
                    "targetTime": "Day 0 18:00"
                }
            ],
            "status": "Unresolved"
        })

        reasoning = (
            f"Conflict Detection Agent ran 48 constraint rules across venue bookings, resource counters, and volunteer shifts. "
            f"Detected {len(conflicts)} active operational bottlenecks with formulated automated resolution options."
        )

        return {
            "conflicts": conflicts,
            "totalDetected": len(conflicts),
            "unresolvedCount": len([c for c in conflicts if c["status"] == "Unresolved"]),
            "reasoning": reasoning,
            "status": "Warning" if len(conflicts) > 0 else "Clean"
        }

    def resolve_conflict(self, conflict_id, option_id, all_conflicts):
        resolved_conflict = None
        for c in all_conflicts:
            if c["id"] == conflict_id:
                c["status"] = "Resolved"
                c["selectedOption"] = option_id
                resolved_conflict = c
                break
        return resolved_conflict, all_conflicts
