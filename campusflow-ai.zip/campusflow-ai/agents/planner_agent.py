"""
CampusFlow AI - Production Event Planner Agent
Central orchestration starting point for natural-language requirement understanding,
normalization, constraint analysis, task generation, schedule synthesis, and replanning.
"""

import re
import os
import uuid
import datetime
import logging
from typing import Dict, Any, List, Optional, Tuple

import sys
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from services.ai_service import AIService
from models.event_models import Event, EventRequirement, EventPlan, EventTask, AgentRun, PlannerOutput

logger = logging.getLogger("EventPlannerAgent")


class EventPlannerAgent:
    """
    Production-grade Event Planner Agent:
    - Parses natural language and structured event requests
    - Extracts & normalizes multi-dimensional event specifications
    - Detects missing information (required vs optional)
    - Formulates transparent operational assumptions
    - Evaluates capacity, time, resource, and security constraints
    - Synthesizes preliminary schedules and prioritized work orders
    - Identifies security-sensitive actions requiring human approval
    - Provides dynamic replanning when conditions change
    - Produces clean PlannerOutput interfaces for downstream agent collaboration
    """

    def __init__(self, ai_service: Optional[AIService] = None):
        self.name = "Event Planner Agent"
        self.role = "Requirement Understanding & Blueprint Architect"
        self.ai_service = ai_service or AIService()
        
        # Configurable priority rules
        self.priority_matrix = {
            "security": "critical",
            "overnight_permit": "critical",
            "venue_confirmation": "high",
            "wifi_infrastructure": "critical",
            "equipment_setup": "high",
            "mentor_onboarding": "high",
            "volunteer_briefing": "high",
            "catering_confirmation": "medium",
            "registration_desk": "medium",
            "signage_decoration": "low",
            "attendee_kits": "low"
        }

    # =========================================================================
    # 1. INPUT VALIDATION
    # =========================================================================
    def validate_input(self, data: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
        """
        Validates incoming request data (natural language or structured).
        Returns: (is_valid, error_messages, sanitized_data)
        """
        errors = []
        sanitized = {}

        if not data:
            return False, ["Request payload cannot be empty."], {}

        prompt = data.get("prompt")
        name = data.get("name")
        event_type = data.get("eventType")
        start_date = data.get("startDate")
        end_date = data.get("endDate")
        participants = data.get("expectedParticipants")
        requirements = data.get("requirements")

        # Case A: Natural language prompt
        if prompt is not None:
            if not isinstance(prompt, str) or not prompt.strip():
                errors.append("The 'prompt' field must be a non-empty string.")
            sanitized["prompt"] = prompt.strip() if isinstance(prompt, str) else ""

        # Case B: Structured fields validation
        if name is not None:
            if not isinstance(name, str) or not name.strip():
                errors.append("Event 'name' must be a non-empty string.")
            sanitized["name"] = name.strip()

        if event_type is not None:
            normalized_type = self._normalize_event_type(event_type)
            sanitized["eventType"] = normalized_type

        if participants is not None:
            try:
                part_int = int(participants)
                if part_int <= 0:
                    errors.append("Participant count ('expectedParticipants') must be a positive integer.")
                else:
                    sanitized["expectedParticipants"] = part_int
            except (ValueError, TypeError):
                errors.append("Participant count ('expectedParticipants') must be a valid positive number.")

        if start_date is not None:
            sanitized["startDate"] = str(start_date).strip()

        if end_date is not None:
            sanitized["endDate"] = str(end_date).strip()

        # Date ordering validation
        if sanitized.get("startDate") and sanitized.get("endDate"):
            try:
                d1 = datetime.datetime.strptime(sanitized["startDate"][:10], "%Y-%m-%d")
                d2 = datetime.datetime.strptime(sanitized["endDate"][:10], "%Y-%m-%d")
                if d1 > d2:
                    errors.append("Event 'startDate' cannot be after 'endDate'.")
            except ValueError:
                # If date format is non-standard string, allow if parseable or flag
                pass

        if requirements is not None:
            if not isinstance(requirements, list):
                errors.append("'requirements' must be an array of strings or requirement objects.")
            sanitized["requirements"] = requirements

        # Ensure either prompt or structured name is provided
        if not sanitized.get("prompt") and not sanitized.get("name"):
            errors.append("Either a natural-language 'prompt' or structured event 'name' must be provided.")

        is_valid = len(errors) == 0
        return is_valid, errors, sanitized

    def _normalize_event_type(self, raw_type: str) -> str:
        t = raw_type.lower().strip().replace("-", "_").replace(" ", "_")
        if "hack" in t:
            return "hackathon"
        if "work" in t or "hands" in t:
            return "workshop"
        if "conf" in t or "symp" in t:
            return "conference"
        if "fest" in t or "tech" in t:
            return "technical_fest"
        if "place" in t or "drive" in t or "recruit" in t:
            return "placement_drive"
        if "seminar" in t:
            return "seminar"
        if "cultural" in t:
            return "cultural_event"
        return t or "general"

    # =========================================================================
    # 2. CORE PLANNING ENGINE (PLAN GENERATION)
    # =========================================================================
    def plan_event(self, request_data: Dict[str, Any], event_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Main entry point for creating an end-to-end event operational plan.
        """
        logger.info(f"[EventPlannerAgent] Request received: {request_data.get('prompt') or request_data.get('name')}")

        # 1. Validate Input
        is_valid, errors, validated = self.validate_input(request_data)
        if not is_valid:
            return {
                "success": False,
                "errors": errors,
                "message": "Input validation failed. " + " ".join(errors)
            }

        logger.info("[EventPlannerAgent] Validation completed successfully.")
        event_id = event_id or request_data.get("id") or f"evt-{uuid.uuid4().hex[:6]}"

        # 2. Extract Requirements
        logger.info("[EventPlannerAgent] Extracting requirements...")
        extraction, source_provider, confidence, fallback_notice = self._extract_requirements(validated)

        # Merge any explicit structured overrides
        event_info = extraction["event"]
        if validated.get("name"):
            event_info["name"] = validated["name"]
        if validated.get("eventType"):
            event_info["type"] = validated["eventType"]
        if validated.get("expectedParticipants"):
            event_info["expectedParticipants"] = validated["expectedParticipants"]
        if validated.get("startDate"):
            event_info["startDate"] = validated["startDate"]
        if validated.get("endDate"):
            event_info["endDate"] = validated["endDate"]

        event_info["id"] = event_id

        # 3. Detect Missing Information & Assumptions
        missing_info = self._detect_missing_information(event_info, extraction)
        assumptions = self._generate_assumptions(event_info, extraction)

        # 4. Perform Multi-Dimensional Constraint Analysis
        logger.info("[EventPlannerAgent] Performing constraint analysis...")
        constraints = self._analyze_constraints(event_info, extraction)

        # 5. Generate Preliminary Schedule
        logger.info("[EventPlannerAgent] Generating preliminary schedule...")
        schedule = self._generate_preliminary_schedule(event_info, extraction)

        # 6. Generate Operational Tasks with Priority Classification
        logger.info("[EventPlannerAgent] Generating operational tasks and work orders...")
        tasks = self._generate_operational_tasks(event_id, event_info, extraction)

        # 7. Check for Security-Sensitive Human Approval Gates
        human_approvals = self._detect_human_approval_requirements(event_id, event_info, extraction)

        # 8. Assemble Full Plan Structure
        event_plan = {
            "id": f"plan-{event_id}",
            "eventId": event_id,
            "status": "preliminary",
            "readinessScore": 85 if not human_approvals else 75,
            "eventOverview": event_info,
            "venueRequirements": extraction.get("venueRequirements", []),
            "equipmentRequirements": extraction.get("equipmentRequirements", []),
            "staffingRequirements": extraction.get("staffingRequirements", []),
            "serviceRequirements": extraction.get("serviceRequirements", []),
            "specialRequirements": extraction.get("specialRequirements", []),
            "schedule": schedule,
            "tasks": tasks,
            "constraints": constraints,
            "assumptions": assumptions,
            "missingInformation": missing_info,
            "humanApprovalRequirements": human_approvals,
            "confidence": confidence,
            "source": source_provider,
            "fallbackNotice": fallback_notice,
            "createdAt": datetime.datetime.now().isoformat(),
            "updatedAt": datetime.datetime.now().isoformat()
        }

        # 9. Format Standardized PlannerOutput for downstream agents
        planner_output = PlannerOutput(
            event=event_info,
            venueRequirements=extraction.get("venueRequirements", []),
            equipmentRequirements=extraction.get("equipmentRequirements", []),
            staffingRequirements=extraction.get("staffingRequirements", []),
            serviceRequirements=extraction.get("serviceRequirements", []),
            schedule=schedule,
            tasks=tasks,
            constraints=constraints,
            assumptions=assumptions,
            missingInformation=missing_info,
            humanApprovalRequirements=human_approvals,
            confidence=confidence,
            source=source_provider
        )

        logger.info(f"[EventPlannerAgent] Plan generated successfully for {event_info['name']} ({event_id}).")

        return {
            "success": True,
            "event": {
                "id": event_id,
                "name": event_info["name"],
                "type": event_info["type"],
                "startDate": event_info.get("startDate"),
                "endDate": event_info.get("endDate"),
                "expectedParticipants": event_info.get("expectedParticipants", 0),
                "duration": event_info.get("duration", "1 Day"),
                "status": "In Planning"
            },
            "agent": {
                "name": self.name,
                "status": "completed",
                "role": self.role,
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S")
            },
            "analysis": {
                "confidence": confidence,
                "source": source_provider,
                "fallbackNotice": fallback_notice,
                "missingInformation": missing_info,
                "assumptions": assumptions,
                "requiresHumanApproval": len(human_approvals) > 0,
                "approvalCount": len(human_approvals)
            },
            "plan": event_plan,
            "plannerOutput": planner_output.to_dict()
        }

    # =========================================================================
    # 3. REQUIREMENT EXTRACTION & NORMALIZATION
    # =========================================================================
    def _extract_requirements(self, validated: Dict[str, Any]) -> Tuple[Dict[str, Any], str, float, Optional[str]]:
        prompt = validated.get("prompt")
        
        # If natural language prompt is available, pass through AI service
        if prompt:
            extraction, provider, conf, notice = self.ai_service.generate_structured_output(prompt)
            return extraction, provider, conf, notice

        # If pure structured input was provided
        req_list = validated.get("requirements", [])
        name = validated.get("name", "Campus Event 2026")
        evt_type = validated.get("eventType", "general")
        part = validated.get("expectedParticipants", 100)
        s_date = validated.get("startDate")
        e_date = validated.get("endDate")

        # Synthesize from structured requirement tags
        venues = []
        equipment = []
        staffing = []
        services = []
        special = []

        lower_reqs = [str(r).lower() for r in req_list]
        
        if any("auditorium" in r for r in lower_reqs):
            venues.append({"type": "auditorium", "name": "Main Auditorium", "requiredCapacity": part, "purpose": "Main sessions"})
        if any("lab" in r for r in lower_reqs):
            venues.append({"type": "computer_lab", "name": "Computer Labs 1 & 2", "requiredCapacity": part, "purpose": "Hands-on tracks"})

        if any("projector" in r for r in lower_reqs):
            equipment.append({"type": "projector", "name": "HD Projectors", "quantity": 4, "priority": "high"})
        if any("wifi" in r or "wi-fi" in r for r in lower_reqs):
            equipment.append({"type": "wifi", "name": "Dedicated Event Wi-Fi VLAN", "quantity": 1, "priority": "critical"})

        if any("mentor" in r for r in lower_reqs):
            staffing.append({"role": "mentor", "title": "Mentors & Evaluators", "quantity": 10, "priority": "high"})
        if any("volunteer" in r for r in lower_reqs):
            staffing.append({"role": "volunteer", "title": "Student Logistics Volunteers", "quantity": 12, "priority": "high"})

        if any("food" in r or "catering" in r for r in lower_reqs):
            services.append({"type": "catering", "name": "Event Catering & Meals", "required": True})
        if any("security" in r for r in lower_reqs):
            services.append({"type": "security", "name": "Campus Security Escorts", "required": True})

        extraction = {
            "event": {
                "name": name,
                "type": evt_type,
                "description": f"{name} ({evt_type}) with {part} expected participants.",
                "startDate": s_date,
                "endDate": e_date,
                "duration": "1 Day" if s_date == e_date else "2 Days",
                "durationDays": 1 if s_date == e_date else 2,
                "expectedParticipants": part,
                "workingHours": "09:00–21:00",
                "isOvernight": False
            },
            "venueRequirements": venues,
            "equipmentRequirements": equipment,
            "staffingRequirements": staffing,
            "serviceRequirements": services,
            "specialRequirements": special,
            "flags": {
                "wifiRequired": any("wifi" in r or "wi-fi" in r for r in lower_reqs),
                "foodRequired": any("food" in r for r in lower_reqs),
                "securityRequired": any("security" in r for r in lower_reqs),
                "isOvernight": False
            }
        }
        return extraction, "Structured Input Parser", 0.98, None

    # =========================================================================
    # 4. MISSING INFORMATION & ASSUMPTIONS
    # =========================================================================
    def _detect_missing_information(self, event_info: Dict[str, Any], extraction: Dict[str, Any]) -> Dict[str, List[str]]:
        required_missing = []
        optional_missing = []

        if not event_info.get("startDate"):
            required_missing.append("startDate")
        if not event_info.get("endDate"):
            required_missing.append("endDate")
        if not event_info.get("expectedParticipants") or event_info.get("expectedParticipants") <= 0:
            required_missing.append("expectedParticipants")
        if not extraction.get("venueRequirements"):
            required_missing.append("venueRequirements")

        if not extraction.get("equipmentRequirements"):
            optional_missing.append("equipmentDetails")
        if not extraction.get("staffingRequirements"):
            optional_missing.append("staffingRequirements")
        if "budget" not in event_info:
            optional_missing.append("budgetAllocation")
        if "cateringPreferences" not in event_info:
            optional_missing.append("dietaryAndCateringPreferences")

        return {
            "required": required_missing,
            "optional": optional_missing
        }

    def _generate_assumptions(self, event_info: Dict[str, Any], extraction: Dict[str, Any]) -> List[str]:
        assumptions = []
        working_hours = event_info.get("workingHours", "09:00–21:00")
        assumptions.append(f"Default daily operational schedule is assumed as {working_hours}.")
        
        part = event_info.get("expectedParticipants", 100)
        reg_desks = max(2, part // 50)
        assumptions.append(f"Allocating {reg_desks} attendee check-in / badge registration counters based on {part} participants.")
        assumptions.append("Dedicated campus Wi-Fi SSID with 1 Gbps uplink assumed for all registered participants.")
        assumptions.append("Two AV & Network Technical Support staff assumed for all plenary sessions.")

        if event_info.get("isOvernight"):
            assumptions.append("Overnight security gate escorts and paramedic standby required from 22:00 to 06:00.")
        else:
            assumptions.append("Standard daytime campus building hours apply (no overnight dorm or building access needed).")

        return assumptions

    # =========================================================================
    # 5. CONSTRAINT ANALYSIS
    # =========================================================================
    def _analyze_constraints(self, event_info: Dict[str, Any], extraction: Dict[str, Any]) -> List[Dict[str, Any]]:
        constraints = []
        part = event_info.get("expectedParticipants", 100)
        duration_days = event_info.get("durationDays", 1)
        is_overnight = event_info.get("isOvernight", False)

        # 1. Capacity Constraints
        constraints.append({
            "type": "capacity",
            "category": "venue",
            "description": f"Main venue space must comfortably seat and support at least {part} participants simultaneously.",
            "severity": "high" if part >= 150 else "medium",
            "targetMetric": f"{part} Seats"
        })

        # 2. Time & Setup Constraints
        constraints.append({
            "type": "time",
            "category": "schedule",
            "description": "AV setup, stage soundcheck, and registration counter staging must complete 60 minutes prior to inaugural kickoff.",
            "severity": "high",
            "targetMetric": "60m Pre-Event Buffer"
        })

        # 3. Resource / Network Constraints
        if any(e.get("type") == "wifi" for e in extraction.get("equipmentRequirements", [])):
            constraints.append({
                "type": "resource",
                "category": "network",
                "description": f"High-density Wi-Fi infrastructure must support {int(part * 1.5)} concurrent active devices.",
                "severity": "critical",
                "targetMetric": f"{int(part * 1.5)} Active Connections"
            })

        # 4. Operational / Security Constraints
        if is_overnight or duration_days > 1:
            constraints.append({
                "type": "operational",
                "category": "security",
                "description": "24/7 overnight campus perimeter control and formal Dean's clearance required.",
                "severity": "critical",
                "targetMetric": "Dean & Security Sign-Off"
            })

        return constraints

    # =========================================================================
    # 6. PRELIMINARY SCHEDULE GENERATION
    # =========================================================================
    def _generate_preliminary_schedule(self, event_info: Dict[str, Any], extraction: Dict[str, Any]) -> List[Dict[str, Any]]:
        evt_type = event_info.get("type", "general")
        duration_days = event_info.get("durationDays", 1)
        schedule_days = []

        if evt_type == "hackathon":
            day1_items = [
                {"time": "09:00 - 09:30", "title": "Registration & Welcome Kit Distribution", "venue": "Main Foyer", "status": "preliminary"},
                {"time": "09:30 - 10:00", "title": "Inauguration Ceremony & Keynote Address", "venue": "Main Auditorium", "status": "preliminary"},
                {"time": "10:00 - 10:30", "title": "Hackathon Problem Statements Release & Rules", "venue": "Main Auditorium", "status": "preliminary"},
                {"time": "10:30 - 13:00", "title": "Hacking Sprint 1: Ideation & Architecture", "venue": "Auditorium & Labs", "status": "preliminary"},
                {"time": "13:00 - 14:00", "title": "Lunch Break & Networking", "venue": "Dining Courtyard", "status": "preliminary"},
                {"time": "14:00 - 17:30", "title": "Mentoring Session 1 & Technical Development", "venue": "Computer Labs", "status": "preliminary"},
                {"time": "18:00 - 19:30", "title": "Midway Progress Review", "venue": "Assigned Hacker Bays", "status": "preliminary"},
                {"time": "20:00 - 21:00", "title": "Dinner & Community Hour", "venue": "Dining Courtyard", "status": "preliminary"}
            ]
            if event_info.get("isOvernight"):
                day1_items.append({"time": "23:59 - 00:30", "title": "Midnight Energy Snacks & Gaming Break", "venue": "Main Foyer", "status": "preliminary"})

            schedule_days.append({"day": 1, "date": event_info.get("startDate", "Day 1"), "items": day1_items})

            if duration_days > 1:
                day2_items = [
                    {"time": "08:00 - 09:00", "title": "Breakfast & Coffee", "venue": "Dining Courtyard", "status": "preliminary"},
                    {"time": "09:00 - 12:30", "title": "Hacking Sprint 2: Testing & Integration", "venue": "Computer Labs", "status": "preliminary"},
                    {"time": "13:00 - 14:00", "title": "Lunch Break", "venue": "Dining Courtyard", "status": "preliminary"},
                    {"time": "15:00", "title": "Final GitHub Code Freeze & Submission", "venue": "Portal Submission", "status": "preliminary"},
                    {"time": "16:00 - 17:45", "title": "Jury Evaluation & Finalist Demos", "venue": "Main Auditorium", "status": "preliminary"},
                    {"time": "18:00 - 18:30", "title": "Results Declaration & Awards", "venue": "Main Auditorium", "status": "preliminary"},
                    {"time": "18:30 - 19:00", "title": "Closing Ceremony & Valedictory", "venue": "Main Auditorium", "status": "preliminary"}
                ]
                schedule_days.append({"day": 2, "date": event_info.get("endDate", "Day 2"), "items": day2_items})
        else:
            # General / Workshop / Symposium schedule
            day1_items = [
                {"time": "09:00 - 09:45", "title": "Participant Registration & Reception", "venue": "Main Foyer", "status": "preliminary"},
                {"time": "10:00 - 11:15", "title": "Inaugural Keynote & Opening Remarks", "venue": "Main Auditorium", "status": "preliminary"},
                {"time": "11:30 - 13:00", "title": "Core Technical Sessions / Workshop Track", "venue": "Auditorium & Labs", "status": "preliminary"},
                {"time": "13:00 - 14:00", "title": "Networking Lunch", "venue": "Dining Courtyard", "status": "preliminary"},
                {"time": "14:15 - 16:30", "title": "Interactive Hands-on Labs & Panel Q&A", "venue": "Computer Labs", "status": "preliminary"},
                {"time": "16:45 - 17:30", "title": "Valedictory & Certificate Distribution", "venue": "Main Auditorium", "status": "preliminary"}
            ]
            schedule_days.append({"day": 1, "date": event_info.get("startDate", "Day 1"), "items": day1_items})

        return schedule_days

    # =========================================================================
    # 7. TASK GENERATION & PRIORITY CALCULATION
    # =========================================================================
    def _generate_operational_tasks(self, event_id: str, event_info: Dict[str, Any], extraction: Dict[str, Any]) -> List[Dict[str, Any]]:
        tasks = []
        base_date = event_info.get("startDate", "2026-09-12")

        # 1. Security & Approvals
        if event_info.get("isOvernight") or any(s.get("requiresHumanApproval") for s in extraction.get("specialRequirements", [])):
            tasks.append({
                "id": f"tsk-sec-{uuid.uuid4().hex[:5]}",
                "eventId": event_id,
                "title": "Obtain security and overnight campus approval",
                "description": "Secure formal written sign-off from Chief Security Officer & Dean for overnight access.",
                "category": "security",
                "priority": "critical",
                "status": "pending",
                "deadline": f"{base_date} 08:00",
                "assignedTo": "Security Lead / Dean Office",
                "dependencies": [],
                "requiresHumanApproval": True,
                "approvalType": "security"
            })

        # 2. Venue Lock
        tasks.append({
            "id": f"tsk-ven-{uuid.uuid4().hex[:5]}",
            "eventId": event_id,
            "title": "Confirm and reserve venue allocations",
            "description": "Lock Main Auditorium and designated computer labs on campus scheduling portal.",
            "category": "venue",
            "priority": "high",
            "status": "pending",
            "deadline": f"{base_date} 08:00",
            "assignedTo": "Campus Facility Manager",
            "dependencies": []
        })

        # 3. Wi-Fi & Network Provisioning
        tasks.append({
            "id": f"tsk-net-{uuid.uuid4().hex[:5]}",
            "eventId": event_id,
            "title": "Configure high-speed event Wi-Fi VLAN & SSID",
            "description": "Deploy dedicated 1 Gbps SSID with captive portal bypass for hacker devices.",
            "category": "equipment",
            "priority": "critical",
            "status": "pending",
            "deadline": f"{base_date} 08:30",
            "assignedTo": "IT & Network Cell Lead",
            "dependencies": ["Confirm and reserve venue allocations"]
        })

        # 4. AV & Projector Setup
        tasks.append({
            "id": f"tsk-av-{uuid.uuid4().hex[:5]}",
            "eventId": event_id,
            "title": "Arrange and soundcheck HD projectors and PA audio",
            "description": "Position 6 HD projectors, test wireless mics, and soundcheck auditorium speakers.",
            "category": "equipment",
            "priority": "high",
            "status": "pending",
            "deadline": f"{base_date} 08:30",
            "assignedTo": "AV Technician",
            "dependencies": ["Confirm and reserve venue allocations"]
        })

        # 5. Volunteer Rostering
        tasks.append({
            "id": f"tsk-vol-{uuid.uuid4().hex[:5]}",
            "eventId": event_id,
            "title": "Assign and brief student volunteer roster",
            "description": "Mobilize 15 student volunteers across registration, technical assistance, and hospitality stations.",
            "category": "staffing",
            "priority": "high",
            "status": "pending",
            "deadline": f"{base_date} 08:00",
            "assignedTo": "Student Volunteer Lead",
            "dependencies": []
        })

        # 6. Catering Confirmation
        tasks.append({
            "id": f"tsk-cat-{uuid.uuid4().hex[:5]}",
            "eventId": event_id,
            "title": "Confirm participant catering and refreshment schedule",
            "description": "Verify breakfast, lunch, and dinner delivery timings with campus mess/vendor.",
            "category": "catering",
            "priority": "medium",
            "status": "pending",
            "deadline": f"{base_date} 09:00",
            "assignedTo": "Hospitality Coordinator",
            "dependencies": []
        })

        # 7. Registration Desks & Badge Printing
        tasks.append({
            "id": f"tsk-reg-{uuid.uuid4().hex[:5]}",
            "eventId": event_id,
            "title": "Setup registration counters and attendee kits",
            "description": "Assemble check-in kiosks, QR scanners, and welcome badge lanyards in main foyer.",
            "category": "registration",
            "priority": "medium",
            "status": "pending",
            "deadline": f"{base_date} 08:30",
            "assignedTo": "Registration Team",
            "dependencies": []
        })

        # 8. Signage & Directional Banners
        tasks.append({
            "id": f"tsk-sig-{uuid.uuid4().hex[:5]}",
            "eventId": event_id,
            "title": "Deploy campus directional signage and standees",
            "description": "Place directional banners from main gate to auditorium and hacker labs.",
            "category": "logistics",
            "priority": "low",
            "status": "pending",
            "deadline": f"{base_date} 08:30",
            "assignedTo": "Logistics Volunteer",
            "dependencies": []
        })

        return tasks

    # =========================================================================
    # 8. SECURITY-SENSITIVE ACTIONS & HUMAN APPROVALS
    # =========================================================================
    def _detect_human_approval_requirements(self, event_id: str, event_info: Dict[str, Any], extraction: Dict[str, Any]) -> List[Dict[str, Any]]:
        approvals = []
        
        if event_info.get("isOvernight"):
            approvals.append({
                "id": f"appr-sec-{uuid.uuid4().hex[:5]}",
                "eventId": event_id,
                "title": "Overnight Campus Building Access Clearance",
                "category": "Security / Campus Administration",
                "approvalType": "security",
                "requiresHumanApproval": True,
                "status": "Pending Human Approval",
                "requestedBy": self.name,
                "assignedRole": "Chief Security Officer / Dean of Student Affairs",
                "description": "Requesting 24-hour access to Main Auditorium and Computer Labs for hackathon participants and mentors.",
                "auditTrail": [
                    {
                        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "action": "Triggered by Event Planner Agent (Overnight Hackathon Detected)",
                        "actor": "Event Planner Agent"
                    }
                ]
            })

        return approvals

    # =========================================================================
    # 9. REPLANNING ENGINE
    # =========================================================================
    def replan(self, event_id: str, change_description: str, current_state: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Handles real-time disturbances or plan modifications:
        - Identifies affected requirements, venues, schedules, resources
        - Calculates ripple effects
        - Produces revised preliminary plan and flags approval if sensitive
        """
        logger.info(f"[EventPlannerAgent] Replanning triggered for {event_id}: '{change_description}'")
        lower = change_description.lower()
        affected_areas = []
        reason = change_description

        venue_impacted = any(w in lower for w in ["venue", "auditorium", "lab", "room", "hall", "unavailable", "booked"])
        resource_impacted = any(w in lower for w in ["projector", "mic", "wifi", "power", "equipment", "hardware", "broken", "failed"])
        schedule_impacted = any(w in lower for w in ["delay", "postpone", "reschedule", "time", "hour", "rain", "storm"])
        staff_impacted = any(w in lower for w in ["mentor", "volunteer", "speaker", "cancel", "sick", "unavailable"])
        capacity_impacted = any(w in lower for w in ["capacity", "surge", "more students", "registered", "participants"])

        if venue_impacted:
            affected_areas.append("venue")
            affected_areas.append("schedule")
            affected_areas.append("equipment")
        if resource_impacted:
            affected_areas.append("equipment")
            affected_areas.append("schedule")
        if schedule_impacted:
            affected_areas.append("schedule")
        if staff_impacted:
            affected_areas.append("staffing")
        if capacity_impacted:
            affected_areas.append("capacity")
            affected_areas.append("catering")
            affected_areas.append("venue")

        if not affected_areas:
            affected_areas = ["operational_tasks", "schedule"]

        remediation_summary = (
            f"Event Planner identified ripple effects across {', '.join(affected_areas).upper()}. "
            f"Calculated updated capacity boundaries and marked primary assets for dynamic rerouting."
        )

        requires_human = "budget" in lower or "security" in lower or "cancel" in lower

        return {
            "success": True,
            "replanningRequired": True,
            "eventId": event_id,
            "reason": reason,
            "affectedAreas": list(set(affected_areas)),
            "remediationSummary": remediation_summary,
            "requiresHumanApproval": requires_human,
            "approvalType": "administrative" if requires_human else None,
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S")
        }

    # =========================================================================
    # 10. BACKWARDS COMPATIBILITY (LEGACY ANALYZE METHOD)
    # =========================================================================
    def analyze_requirements(self, prompt_text: str) -> Dict[str, Any]:
        """
        Backwards-compatible wrapper that returns the existing specification format.
        """
        plan_result = self.plan_event({"prompt": prompt_text})
        if not plan_result.get("success"):
            return {
                "eventType": "College Seminar",
                "participants": 150,
                "duration": "1 Day",
                "daysCount": 1,
                "dates": "September 12 - 13, 2026",
                "venues": ["Main Auditorium"],
                "equipment": ["High-Lumen Projectors"],
                "staffing": ["12 Student Volunteers"],
                "food": ["Standard Refreshments"],
                "security": ["Daytime Campus Security Guards"],
                "specialRequirements": [],
                "isOvernight": False,
                "reasoning": "Fallback analysis executed.",
                "confidenceScore": 90.0,
                "timestamp": datetime.datetime.now().strftime("%H:%M:%S")
            }

        plan = plan_result["plan"]
        overview = plan["eventOverview"]
        venues = [v["name"] for v in plan.get("venueRequirements", [])]
        equip = [e["name"] for e in plan.get("equipmentRequirements", [])]
        staff = [s["title"] for s in plan.get("staffingRequirements", [])]
        food = [s["name"] for s in plan.get("serviceRequirements", []) if "catering" in s.get("type", "")]
        sec = [s["name"] for s in plan.get("serviceRequirements", []) if "security" in s.get("type", "")]
        special = [r["description"] for r in plan.get("specialRequirements", [])]

        return {
            "id": overview.get("id", "evt-001"),
            "eventType": overview.get("type", "hackathon").replace("_", " ").title(),
            "participants": overview.get("expectedParticipants", 150),
            "duration": overview.get("duration", "2 Days"),
            "daysCount": overview.get("durationDays", 2),
            "dates": f"{overview.get('startDate', '2026-09-12')} to {overview.get('endDate', '2026-09-13')}",
            "venues": venues if venues else ["Main Auditorium", "Computer Lab 1"],
            "equipment": equip if equip else ["High-Lumen Projectors", "Wi-Fi Mesh"],
            "staffing": staff if staff else ["20 Industry Mentors", "15 Volunteers"],
            "food": food if food else ["Participant Meals & Snacks"],
            "security": sec if sec else ["Campus Security Escorts"],
            "specialRequirements": special,
            "isOvernight": overview.get("isOvernight", False),
            "reasoning": f"Event Planner Agent synthesized operational footprint for {overview.get('name')}.",
            "confidenceScore": float(plan.get("confidence", 0.95) * 100),
            "timestamp": datetime.datetime.now().strftime("%H:%M:%S")
        }
