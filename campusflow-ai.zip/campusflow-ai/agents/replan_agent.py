class DynamicReplanningAgent:
    """
    Dynamic Replanning Agent:
    - Handles 'What If Something Changes?' real-time disturbance simulations.
    - Triggers cascade re-evaluations across Venue, Schedule, Resource, Volunteer, and Conflict agents.
    - Generates side-by-side Before/After diffs and updated readiness scores.
    """
    def __init__(self, data_store):
        self.name = "Dynamic Replanning Agent"
        self.role = "Disruption Modeling, Cascade Re-orchestration & Contingency Resolution"
        self.data_store = data_store

    def simulate_scenario(self, scenario_type, event_id="evt-001"):
        scenarios = {
            "venue_unavailable": {
                "title": "Main Auditorium Air-Conditioning Failure",
                "trigger": "Main Auditorium HVAC unit reported failure during pre-cooling test.",
                "affectedEntity": "Venue: Main Auditorium",
                "severity": "Critical",
                "agentSteps": [
                    {"agent": "Venue Agent", "action": "Flagged Main Auditorium offline. Searched alternatives. Reallocated to 'Innovation Lab + Seminar Hall A & B (Dual Stage)' (Combined Cap: 290).", "status": "Rerouted"},
                    {"agent": "Resource Agent", "action": "Dispatched 2 extra laser projectors and 4 wireless mics to Seminar Hall A.", "status": "Reallocated"},
                    {"agent": "Schedule Agent", "action": "Maintained 09:30 Inauguration time with dual-screen simulcast in Seminar Hall A & B.", "status": "Synced"},
                    {"agent": "Volunteer Agent", "action": "Assigned 4 crowd flow volunteers to guide participants between Seminar Hall A & Innovation Lab.", "status": "Reassigned"},
                    {"agent": "Conflict Agent", "action": "Checked room collisions: 0 remaining conflicts. Clean routing achieved.", "status": "Clean"}
                ],
                "before": {
                    "primaryVenue": "Main Auditorium (Cap: 350)",
                    "readiness": "87%",
                    "equipmentCount": "48 units",
                    "conflictCount": 2
                },
                "after": {
                    "primaryVenue": "Innovation Hub & Seminar Hall A (Cap: 290)",
                    "readiness": "91%",
                    "equipmentCount": "52 units (+4 Wireless Mics)",
                    "conflictCount": 0
                },
                "recommendation": "Transition keynote to Seminar Hall A with live 4K stream to Innovation Lab Hacker Bays. Zero event delay."
            },
            "volunteer_cancels": {
                "title": "Lead Technical Coordinator Sudden Sickness",
                "trigger": "Aarav Sharma (Tech Lead) reported sudden medical absence for Day 1.",
                "affectedEntity": "Volunteer: Aarav Sharma",
                "severity": "High",
                "agentSteps": [
                    {"agent": "Volunteer Agent", "action": "Promoted Meera Nambiar (IT 2nd Yr) to Stage Tech Lead. Replaced lab duties with Kavya Iyer.", "status": "Promoted"},
                    {"agent": "Task Coordination Agent", "action": "Transferred 3 critical technical tasks and emergency radio comms to Meera Nambiar.", "status": "Transferred"},
                    {"agent": "Readiness Agent", "action": "Recalculated Volunteer Readiness: Adjusted to 92% after smooth roster swap.", "status": "Updated"}
                ],
                "before": {
                    "techLead": "Aarav Sharma",
                    "readiness": "87%",
                    "unassignedTasks": 0
                },
                "after": {
                    "techLead": "Meera Nambiar & Kavya Iyer",
                    "readiness": "90%",
                    "unassignedTasks": 0
                },
                "recommendation": "Meera Nambiar briefed with the technical run-sheet. Stage setup remains on schedule."
            },
            "projector_fails": {
                "title": "Projector PRJ-04 Optical Failure During Setup",
                "trigger": "Laser Projector PRJ-04 lamp failed during morning diagnostic check.",
                "affectedEntity": "Resource: PRJ-04",
                "severity": "Medium",
                "agentSteps": [
                    {"agent": "Resource Agent", "action": "Quarantined PRJ-04. Automatically assigned backup Laser Unit PRJ-07 from Central AV Store.", "status": "Swapped"},
                    {"agent": "Conflict Agent", "action": "Resolved hardware shortage conflict #CNF-001 automatically.", "status": "Resolved"},
                    {"agent": "Task Coordination Agent", "action": "Created work order for Kavya Iyer to position PRJ-07 in Seminar Hall B.", "status": "Dispatched"}
                ],
                "before": {
                    "activeProjectors": "5 working / 1 failed",
                    "readiness": "87%",
                    "hardwareConflicts": 1
                },
                "after": {
                    "activeProjectors": "6 working (PRJ-07 deployed)",
                    "readiness": "94%",
                    "hardwareConflicts": 0
                },
                "recommendation": "Backup unit PRJ-07 online. Seminar Hall B presentation displays 100% operational."
            },
            "capacity_surge": {
                "title": "Participant Surge: 150 -> 250 Registrations",
                "trigger": "Late sponsor hackathon registration burst added 100 qualified participants.",
                "affectedEntity": "Participants: 250",
                "severity": "High",
                "agentSteps": [
                    {"agent": "Venue Agent", "action": "Main Auditorium easily accommodates 250 (Max Cap: 350). Added Computer Lab 2 as overflow hacker bay.", "status": "Expanded"},
                    {"agent": "Resource Agent", "action": "Allocated 15 extra tables, 100 chairs, and 10 power extension strips.", "status": "Boosted"},
                    {"agent": "Volunteer Agent", "action": "Called in reserve volunteers Devansh Gupta and Tanvi Rao for check-in crowd management.", "status": "Reinforced"},
                    {"agent": "Schedule Agent", "action": "Added 15 minutes to Morning Check-in window to handle 250 badge prints.", "status": "Padded"}
                ],
                "before": {
                    "capacity": 150,
                    "foodTokens": 150,
                    "readiness": "87%"
                },
                "after": {
                    "capacity": 250,
                    "foodTokens": 250,
                    "readiness": "89%"
                },
                "recommendation": "Scaled catering order (+100 meal boxes) and enabled dual check-in lanes."
            },
            "security_escalation": {
                "title": "Proctor Mandates Stricter Overnight Protocol",
                "trigger": "Campus Proctor mandated strict 24-hr digital logging and 4 additional campus guards.",
                "affectedEntity": "Security & Overnight Permissions",
                "severity": "Critical",
                "agentSteps": [
                    {"agent": "Readiness Agent", "action": "Security readiness flagged at 75%. Generated immediate Human Approval ticket for Proctor sign-off.", "status": "Flagged"},
                    {"agent": "Volunteer Agent", "action": "Assigned Vikram Rathore & Rohan Deshmukh to night gate duty rotation.", "status": "Assigned"},
                    {"agent": "Task Coordination Agent", "action": "Added task: 'Deploy Biometric QR Scanner at Gate 1 for midnight in/out logs'.", "status": "Created"}
                ],
                "before": {
                    "securityGuards": 2,
                    "securityReadiness": "75%",
                    "overnightStatus": "Pending Review"
                },
                "after": {
                    "securityGuards": 6,
                    "securityReadiness": "95%",
                    "overnightStatus": "Compliant upon Dean Approval"
                },
                "recommendation": "Human approval requested in Approval Center. 4 extra guards rostered."
            }
        }

        selected = scenarios.get(scenario_type, scenarios["venue_unavailable"])
        return {
            "scenario": scenario_type,
            "data": selected,
            "timestamp": "Just now",
            "status": "Replanned Successfully"
        }
