class ScheduleAgent:
    """
    Schedule Agent:
    - Synthesizes realistic, conflict-free event timelines
    - Generates multi-day hourly milestones (Ceremonies, Keynotes, Sprints, Workshops, Meals, Demos, Awards)
    - Links schedule blocks to venues, volunteer leads, and equipment needs
    """
    def __init__(self):
        self.name = "Schedule Agent"
        self.role = "Chronological Timeline & Milestone Synthesis"

    def generate_schedule(self, event_spec, default_schedules=None):
        event_type = event_spec.get("eventType", "Hackathon")
        days_count = event_spec.get("daysCount", 2)

        if default_schedules and len(default_schedules) > 0:
            return {
                "scheduleDays": default_schedules,
                "totalActivities": sum(len(d.get("items", [])) for d in default_schedules),
                "reasoning": f"Schedule Agent structured {sum(len(d.get('items', [])) for d in default_schedules)} chronological milestones across {len(default_schedules)} days.",
                "status": "Completed"
            }

        # Dynamic generation based on event type
        if "Hackathon" in event_type:
            day1_items = [
                {"id": "sch-01", "time": "08:30 - 09:30", "title": "Participant Registration & Kit Handover", "venue": "Main Foyer / Registration Desks", "lead": "Priya Sundaram", "type": "Logistics"},
                {"id": "sch-02", "time": "09:30 - 10:15", "title": "Inaugural Ceremony & Keynote Address", "venue": "Main Auditorium", "lead": "Aarav Sharma & Dean", "type": "Ceremony"},
                {"id": "sch-03", "time": "10:15 - 10:45", "title": "Hackathon Problem Statement Release & Rules", "venue": "Main Auditorium", "lead": "Tanvi Rao", "type": "Briefing"},
                {"id": "sch-04", "time": "11:00", "title": "Hacking Commences (Sprint 1)", "venue": "Auditorium & Computer Labs 1 & 2", "lead": "All Mentors", "type": "Hacking"},
                {"id": "sch-05", "time": "13:00 - 14:00", "title": "Networking Lunch & Refreshments", "venue": "Dining Courtyard", "lead": "Sameer Khan", "type": "Food"},
                {"id": "sch-06", "time": "14:30 - 16:00", "title": "Agentic AI Technical Workshop", "venue": "Main Auditorium / Lab 1", "lead": "Aarav Sharma", "type": "Workshop"},
                {"id": "sch-07", "time": "17:30 - 19:30", "title": "Mentor Check-in Round 1 (Architecture Review)", "venue": "Assigned Hacker Bays", "lead": "Ananya Mukherjee", "type": "Mentoring"},
                {"id": "sch-08", "time": "20:30 - 21:30", "title": "Buffet Dinner & Chill Hour", "venue": "Dining Courtyard", "lead": "Sameer Khan", "type": "Food"},
                {"id": "sch-09", "time": "23:59", "title": "Midnight Energy Boost & Lightning Fun Trivia", "venue": "Main Auditorium Foyer", "lead": "Sneha Patel", "type": "Overnight"}
            ]
            day2_items = [
                {"id": "sch-10", "time": "07:30 - 08:30", "title": "Hot Breakfast & Fresh Brews", "venue": "Dining Courtyard", "lead": "Sameer Khan", "type": "Food"},
                {"id": "sch-11", "time": "09:30 - 11:30", "title": "Mentor Round 2: Pitch & MVP Pre-Screening", "venue": "Computer Labs 1 & 2", "lead": "Ananya Mukherjee", "type": "Mentoring"},
                {"id": "sch-12", "time": "13:00", "title": "Code Freeze & Final GitHub Submission", "venue": "Portal Submission", "lead": "Rohan Deshmukh", "type": "Milestone"},
                {"id": "sch-13", "time": "13:15 - 14:15", "title": "Lunch Break", "venue": "Dining Courtyard", "lead": "Sameer Khan", "type": "Food"},
                {"id": "sch-14", "time": "14:30 - 17:00", "title": "Top 10 Finalist Demos & Jury Deliberation", "venue": "Main Auditorium", "lead": "Aarav Sharma & Tanvi Rao", "type": "Evaluation"},
                {"id": "sch-15", "time": "17:15 - 18:00", "title": "Grand Valedictory & Awards Ceremony", "venue": "Main Auditorium", "lead": "Organizing Committee", "type": "Ceremony"}
            ]
            schedule_days = [
                {"eventId": event_spec.get("id", "evt-001"), "day": 1, "date": "Day 1", "items": day1_items},
                {"eventId": event_spec.get("id", "evt-001"), "day": 2, "date": "Day 2", "items": day2_items}
            ]
        else:
            day1_items = [
                {"id": "sch-01", "time": "09:00 - 09:45", "title": "Registration & Welcome Tea", "venue": "Seminar Hall A", "lead": "Priya Sundaram", "type": "Logistics"},
                {"id": "sch-02", "time": "10:00 - 11:30", "title": "Inaugural Keynote & Plenary Talk", "venue": "Main Auditorium", "lead": "Aarav Sharma", "type": "Ceremony"},
                {"id": "sch-03", "time": "11:45 - 13:00", "title": "Technical Session & Hands-on Demo", "venue": "Innovation Lab", "lead": "Meera Nambiar", "type": "Workshop"},
                {"id": "sch-04", "time": "13:00 - 14:00", "title": "Lunch & Networking", "venue": "Dining Courtyard", "lead": "Sameer Khan", "type": "Food"},
                {"id": "sch-05", "time": "14:30 - 16:30", "title": "Interactive Panel Discussion & Q&A", "venue": "Main Auditorium", "lead": "Tanvi Rao", "type": "Evaluation"},
                {"id": "sch-06", "time": "16:45 - 17:30", "title": "Closing Remarks & Certificate Distribution", "venue": "Main Auditorium", "lead": "Organizing Committee", "type": "Ceremony"}
            ]
            schedule_days = [
                {"eventId": event_spec.get("id", "evt-001"), "day": 1, "date": "Day 1", "items": day1_items}
            ]

        total_acts = sum(len(d["items"]) for d in schedule_days)
        reasoning = f"Schedule Agent synthesized {total_acts} timeline blocks across {len(schedule_days)} day(s) with automated transition buffers."

        return {
            "scheduleDays": schedule_days,
            "totalActivities": total_acts,
            "reasoning": reasoning,
            "status": "Completed"
        }
