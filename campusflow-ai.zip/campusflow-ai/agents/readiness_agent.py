class EventReadinessAgent:
    """
    Event Readiness Agent:
    - Analyzes readiness across 7 key operational dimensions:
      1. Venue (Lock, Facilities, Power, AC)
      2. Equipment (Projectors, Mics, Audio, Desks, Cables)
      3. Volunteers (Roster filled, station assignments, shifts)
      4. Security (Overnight permit, guards, emergency contacts)
      5. Communication (Discord setup, signage, website, attendee kits)
      6. Transport & Logistics (Guest shuttles, catering delivery access)
      7. Permissions (Dean sign-off, Proctor clearance, Budget sanction)
    - Computes overall composite score and summarizes blockers
    """
    def __init__(self):
        self.name = "Event Readiness Agent"
        self.role = "Operational Readiness Analytics & Blocker Diagnosis"

    def calculate_readiness(self, event_id, state_data):
        # Calculate scores dynamically based on conflicts and approvals
        conflicts = state_data.get("conflicts", [])
        approvals = state_data.get("approvals", [])
        tasks = state_data.get("tasks", [])

        unresolved_conflicts = [c for c in conflicts if c.get("status") == "Unresolved"]
        pending_approvals = [a for a in approvals if a.get("status") == "Pending Human Approval"]
        completed_tasks = [t for t in tasks if t.get("status") == "Completed"]
        
        # Calculate subcategory scores
        venue_score = 100
        equip_score = 100 if len([c for c in unresolved_conflicts if c.get("category") == "Resource"]) == 0 else 80
        vol_score = 100 if len([c for c in unresolved_conflicts if c.get("category") == "Volunteer"]) == 0 else 90
        sec_score = 100 if len([a for a in pending_approvals if "Security" in a.get("category", "")]) == 0 else 75
        comm_score = 95
        trans_score = 85
        perm_score = 100 if len(pending_approvals) == 0 else (70 if len(pending_approvals) > 1 else 85)

        categories = {
            "Venue": venue_score,
            "Equipment": equip_score,
            "Volunteers": vol_score,
            "Security": sec_score,
            "Communication": comm_score,
            "Transport": trans_score,
            "Permissions": perm_score
        }

        overall = int(sum(categories.values()) / len(categories))

        blockers = []
        if equip_score < 100:
            blockers.append("Hardware conflict: High-Lumen Projector PRJ-04 requires re-assignment approval.")
        if sec_score < 100:
            blockers.append("Security Clearance: Overnight campus access requires Dean & Chief Security Officer approval.")
        if perm_score < 100 and len(pending_approvals) > 1:
            blockers.append(f"{len(pending_approvals)} pending human approvals in Approval Center (Security, Budget, Catering vendor).")
        if not blockers:
            blockers.append("All operational checks green! Ready for event launch.")

        summary = (
            f"Event readiness is currently at {overall}%. "
            f"Venue, communications, and volunteer systems are primed. "
            f"{'Resolving ' + str(len(blockers)) + ' operational blockers will elevate the score to 100%.' if blockers and overall < 100 else 'Full operational green light.'}"
        )

        return {
            "overallScore": overall,
            "categories": categories,
            "summary": summary,
            "blockers": blockers,
            "status": "Ready" if overall >= 95 else ("Action Required" if overall >= 80 else "Critical Blockers"),
            "timestamp": "Real-time"
        }
