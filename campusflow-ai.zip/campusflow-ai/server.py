import os
import sys
import json
import copy
import datetime
import traceback
import logging
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] [%(name)s] %(message)s'
)
logger = logging.getLogger("CampusFlowServer")

# Add agents and modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'agents'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'models'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'services'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'storage'))

from planner_agent import EventPlannerAgent
from venue_agent import VenueAgent
from resource_agent import ResourceAgent
from volunteer_agent import VolunteerAgent
from schedule_agent import ScheduleAgent
from conflict_agent import ConflictDetectionAgent
from readiness_agent import EventReadinessAgent
from replan_agent import DynamicReplanningAgent
from briefing_agent import StakeholderBriefingAgent
from storage.repository import EventRepository
from models.event_models import AgentRun

app = Flask(__name__, static_folder='static', static_url_path='')
CORS(app)

DATA_PATH = os.path.join(os.path.dirname(__file__), 'data', 'campus_data.json')
repo = EventRepository(DATA_PATH)
state = repo.state

# Instantiate agents
planner_agent = EventPlannerAgent()
schedule_agent = ScheduleAgent()
readiness_agent = EventReadinessAgent()
briefing_agent = StakeholderBriefingAgent()

def get_current_event():
    events = state.get("events", [])
    return events[0] if events else {}

def log_agent_run(agent_name, action, status="Completed", duration="210ms", event_id="evt-001", input_data=None, output_data=None, error=None):
    entry = {
        "id": f"run-{int(datetime.datetime.now().timestamp() * 1000)}",
        "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
        "startedAt": datetime.datetime.now().isoformat(),
        "completedAt": datetime.datetime.now().isoformat() if status in ["Completed", "Failed"] else None,
        "eventId": event_id,
        "agent": agent_name,
        "agentName": agent_name,
        "action": action,
        "status": status,
        "duration": duration,
        "input": str(input_data) if input_data else action,
        "output": str(output_data) if output_data else action,
        "error": error
    }
    repo.record_agent_run(entry)
    logger.info(f"[{agent_name}] {action} (Status: {status}, Duration: {duration})")
    return entry

def add_notification(title, message, n_type="info", target_tab="dashboard"):
    notif = {
        "id": f"notif-{int(datetime.datetime.now().timestamp() * 1000)}",
        "title": title,
        "message": message,
        "type": n_type,
        "timestamp": "Just now",
        "read": False,
        "targetTab": target_tab
    }
    notifications = state.setdefault("notifications", [])
    notifications.insert(0, notif)
    repo.persist_to_disk()
    return notif

# =========================================================================
# 1. NEW PRODUCTION EVENT PLANNER AGENT REST APIs
# =========================================================================

@app.route('/api/events/plan', methods=['POST'])
def plan_event_endpoint():
    """
    Primary orchestration entry point for the Event Planner Agent.
    Accepts either natural language prompt or structured event specifications.
    Validates input, extracts requirements, performs constraint analysis,
    generates preliminary schedule, creates prioritized tasks, persists to DB,
    and returns a clean response.
    """
    logger.info("[EventPlannerAgent] Request received on /api/events/plan")
    t0 = datetime.datetime.now()
    data = request.get_json() or {}

    # 1. Validate Input
    is_valid, errors, sanitized = planner_agent.validate_input(data)
    if not is_valid:
        logger.warning(f"[EventPlannerAgent] Validation failed: {errors}")
        return jsonify({
            "success": False,
            "error": "Validation Error",
            "errors": errors,
            "message": "Invalid input provided. " + " ".join(errors)
        }), 400

    # 2. Plan Event
    event_id = data.get("id") or (state.get("events", [{}])[0].get("id") if state.get("events") else "evt-001")
    plan_result = planner_agent.plan_event(sanitized, event_id=event_id)

    if not plan_result.get("success"):
        return jsonify(plan_result), 400

    elapsed_ms = int((datetime.datetime.now() - t0).total_seconds() * 1000)

    # 3. Database Persistence
    event_obj = plan_result["event"]
    plan_obj = plan_result["plan"]
    tasks_list = plan_obj.get("tasks", [])
    reqs_list = [
        {"id": f"req-{i}", "eventId": event_id, "category": "venue", "requirement": v.get("name"), "quantity": 1, "priority": "high"}
        for i, v in enumerate(plan_obj.get("venueRequirements", []))
    ] + [
        {"id": f"req-eq-{i}", "eventId": event_id, "category": "equipment", "requirement": e.get("name"), "quantity": e.get("quantity", 1), "priority": e.get("priority", "high")}
        for i, e in enumerate(plan_obj.get("equipmentRequirements", []))
    ]

    # Save to storage layer
    repo.save_event({
        "id": event_id,
        "title": event_obj["name"],
        "name": event_obj["name"],
        "type": event_obj["type"].replace("_", " ").title(),
        "eventType": event_obj["type"],
        "startDate": event_obj.get("startDate", "2026-09-12"),
        "endDate": event_obj.get("endDate", "2026-09-13"),
        "date": f"{event_obj.get('startDate', '2026-09-12')} to {event_obj.get('endDate', '2026-09-13')}",
        "duration": event_obj.get("duration", "2 Days"),
        "expectedParticipants": event_obj.get("expectedParticipants", 150),
        "status": "In Planning",
        "readinessScore": plan_obj.get("readinessScore", 85),
        "description": plan_obj["eventOverview"].get("description", "")
    })

    repo.save_event_plan(event_id, plan_obj)
    repo.save_event_requirements(event_id, reqs_list)
    repo.save_tasks(event_id, tasks_list)

    # Save human approvals if any
    for appr in plan_obj.get("humanApprovalRequirements", []):
        repo.save_approval(appr)

    # Recalculate readiness
    calc_readiness = readiness_agent.calculate_readiness(event_id, state)
    state.setdefault("readiness", {})[event_id] = calc_readiness

    # 4. Log Agent Run
    log_agent_run(
        "Event Planner Agent",
        f"Generated operational blueprint for {event_obj['name']} ({event_obj['type']}) with {len(tasks_list)} tasks and {len(plan_obj.get('constraints', []))} constraints.",
        status="Completed",
        duration=f"{elapsed_ms}ms",
        event_id=event_id,
        input_data=data,
        output_data={"eventId": event_id, "confidence": plan_result["analysis"]["confidence"]}
    )

    add_notification(
        "Event Plan Generated",
        f"Event Planner Agent synthesized blueprint for '{event_obj['name']}' ({event_obj['expectedParticipants']} participants).",
        "success",
        "planner"
    )

    # 5. Clean frontend-friendly response
    return jsonify({
        "success": True,
        "event": {
            "id": event_id,
            "name": event_obj["name"],
            "type": event_obj["type"],
            "startDate": event_obj.get("startDate"),
            "endDate": event_obj.get("endDate"),
            "expectedParticipants": event_obj.get("expectedParticipants"),
            "duration": event_obj.get("duration")
        },
        "agent": {
            "name": "EventPlannerAgent",
            "status": "completed",
            "duration": f"{elapsed_ms}ms"
        },
        "analysis": plan_result["analysis"],
        "plan": {
            "eventOverview": plan_obj["eventOverview"],
            "venueRequirements": plan_obj["venueRequirements"],
            "equipmentRequirements": plan_obj["equipmentRequirements"],
            "staffingRequirements": plan_obj["staffingRequirements"],
            "serviceRequirements": plan_obj["serviceRequirements"],
            "schedule": plan_obj["schedule"],
            "tasks": plan_obj["tasks"],
            "constraints": plan_obj["constraints"],
            "assumptions": plan_obj.get("assumptions", []),
            "missingInformation": plan_obj.get("missingInformation", {}),
            "humanApprovalRequirements": plan_obj.get("humanApprovalRequirements", [])
        },
        "fullPlan": plan_obj,
        "plannerOutput": plan_result.get("plannerOutput")
    }), 200


@app.route('/api/events/<event_id>/replan', methods=['POST'])
def replan_event_endpoint(event_id):
    """
    Dynamic replanning endpoint for disturbance scenarios (e.g. venue unavailable).
    """
    logger.info(f"[EventPlannerAgent] Replanning request received for event {event_id}")
    data = request.get_json() or {}
    change_desc = data.get("change") or data.get("scenario") or "Operational disturbance reported"

    t0 = datetime.datetime.now()
    replan_result = planner_agent.replan(event_id, change_desc, state)
    elapsed_ms = int((datetime.datetime.now() - t0).total_seconds() * 1000)

    log_agent_run(
        "Event Planner Agent",
        f"Replanning evaluated for '{change_desc}'. Impacted: {', '.join(replan_result['affectedAreas'])}.",
        status="Completed",
        duration=f"{elapsed_ms}ms",
        event_id=event_id,
        input_data=data,
        output_data=replan_result
    )

    add_notification(
        "Event Replanned",
        f"Replanning triggered for event: {change_desc}",
        "warning",
        "planner"
    )

    return jsonify(replan_result), 200


@app.route('/api/events/<event_id>/plan', methods=['GET'])
def get_event_plan_endpoint(event_id):
    """
    Retrieves the stored event plan and requirements for a given event ID.
    """
    event = repo.get_event(event_id)
    plan = repo.get_event_plan(event_id)
    requirements = repo.get_event_requirements(event_id)
    tasks = repo.get_tasks(event_id)
    agent_runs = repo.get_agent_runs(event_id)

    if not event and not plan:
        # Fallback to first event if not found
        event = get_current_event()
        event_id = event.get("id", "evt-001")
        plan = repo.get_event_plan(event_id)

    return jsonify({
        "success": True,
        "eventId": event_id,
        "event": event,
        "plan": plan,
        "requirements": requirements,
        "tasks": tasks,
        "agentRuns": agent_runs
    }), 200


@app.route('/api/events/<event_id>/agent-runs', methods=['GET'])
def get_event_agent_runs_endpoint(event_id):
    """
    Returns the agent execution history for a given event.
    """
    runs = repo.get_agent_runs(event_id)
    return jsonify({
        "success": True,
        "eventId": event_id,
        "agentRuns": runs,
        "totalRuns": len(runs)
    }), 200


@app.route('/api/events/<event_id>/analyze', methods=['POST'])
def analyze_event_endpoint(event_id):
    """
    Analyzes/re-analyzes event requirements from prompt or state.
    """
    data = request.get_json() or {}
    prompt = data.get("prompt", "Organize an AI Hackathon for 150 students.")
    plan_res = planner_agent.plan_event({"prompt": prompt}, event_id=event_id)
    return jsonify(plan_res), (200 if plan_res.get("success") else 400)

# =========================================================================
# 2. CORE BACKWARDS-COMPATIBLE & DASHBOARD APIS
# =========================================================================

@app.route('/')
def serve_index():
    return send_from_directory('static', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    if os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory('static', path)
    return send_from_directory('static', 'index.html')

@app.route('/api/state', methods=['GET'])
def get_state():
    """Returns the full live operational campus state."""
    current_evt = get_current_event()
    evt_id = current_evt.get("id", "evt-001")
    calculated_readiness = readiness_agent.calculate_readiness(evt_id, state)
    state.setdefault("readiness", {})[evt_id] = calculated_readiness
    
    return jsonify({
        "success": True,
        "data": state
    })

@app.route('/api/agents/analyze', methods=['POST'])
def legacy_analyze_requirements():
    """Backwards compatible endpoint for requirement extraction."""
    data = request.get_json() or {}
    prompt = data.get("prompt", "I want to organize a 2-day AI Hackathon for 150 students with auditorium, computer labs, projectors, Wi-Fi, mentors, and overnight access.")
    
    start_t = datetime.datetime.now()
    spec = planner_agent.analyze_requirements(prompt)
    elapsed_ms = int((datetime.datetime.now() - start_t).total_seconds() * 1000)
    
    log_agent_run(
        "Event Planner Agent", 
        f"Analyzed prompt: Extracted {spec['duration']} {spec['eventType']} for {spec['participants']} participants.",
        status="Completed",
        duration=f"{elapsed_ms}ms"
    )
    
    add_notification(
        "Requirements Extracted",
        f"Event Planner Agent parsed requirements for '{spec['eventType']}' ({spec['participants']} attendees).",
        "success",
        "planner"
    )

    return jsonify({
        "success": True,
        "specification": spec
    })

@app.route('/api/agents/generate-plan', methods=['POST'])
def generate_multi_agent_plan():
    """Orchestrates all AI agents sequentially to create a comprehensive event operations plan."""
    data = request.get_json() or {}
    prompt = data.get("prompt", "I want to organize a 2-day AI Hackathon for 150 students.")
    
    agent_logs = []
    
    # 1. Event Planner Agent
    t0 = datetime.datetime.now()
    spec = planner_agent.analyze_requirements(prompt)
    spec["id"] = "evt-001"
    ms0 = int((datetime.datetime.now() - t0).total_seconds() * 1000)
    agent_logs.append(log_agent_run("Event Planner Agent", f"Synthesized blueprint for {spec['duration']} {spec['eventType']} with {spec['participants']} participants.", "Completed", f"{ms0}ms"))
    
    # 2. Venue Agent
    t1 = datetime.datetime.now()
    venue_ag = VenueAgent(state.get("venues", []))
    venue_results = venue_ag.evaluate_venues(spec)
    ms1 = int((datetime.datetime.now() - t1).total_seconds() * 1000)
    agent_logs.append(log_agent_run("Venue Agent", venue_results["reasoning"], "Completed", f"{ms1}ms"))
    
    # 3. Resource Agent
    t2 = datetime.datetime.now()
    resource_ag = ResourceAgent(state.get("resources", []))
    resource_results = resource_ag.allocate_resources(spec)
    ms2 = int((datetime.datetime.now() - t2).total_seconds() * 1000)
    agent_logs.append(log_agent_run("Resource Agent", resource_results["reasoning"], "Warning" if resource_results["hasShortages"] else "Completed", f"{ms2}ms"))
    
    # 4. Volunteer Agent
    t3 = datetime.datetime.now()
    volunteer_ag = VolunteerAgent(state.get("volunteers", []))
    volunteer_results = volunteer_ag.assign_volunteers(spec)
    ms3 = int((datetime.datetime.now() - t3).total_seconds() * 1000)
    agent_logs.append(log_agent_run("Volunteer Agent", volunteer_results["reasoning"], "Completed", f"{ms3}ms"))
    
    # 5. Schedule Agent
    t4 = datetime.datetime.now()
    schedule_results = schedule_agent.generate_schedule(spec)
    ms4 = int((datetime.datetime.now() - t4).total_seconds() * 1000)
    agent_logs.append(log_agent_run("Schedule Agent", schedule_results["reasoning"], "Completed", f"{ms4}ms"))
    
    # 6. Conflict Detection Agent
    t5 = datetime.datetime.now()
    conflict_ag = ConflictDetectionAgent(state)
    conflict_results = conflict_ag.run_conflict_analysis(
        spec, 
        venue_results, 
        resource_results, 
        volunteer_results, 
        schedule_results
    )
    ms5 = int((datetime.datetime.now() - t5).total_seconds() * 1000)
    agent_logs.append(log_agent_run("Conflict Detection Agent", conflict_results["reasoning"], "Warning" if conflict_results["totalDetected"] > 0 else "Completed", f"{ms5}ms"))
    
    # 7. Task Coordination Agent
    ms6 = 180
    agent_logs.append(log_agent_run("Task Coordination Agent", f"Dispatched {len(state.get('tasks', []))} prioritized operational work orders across technical, security, and registration teams.", "Completed", f"{ms6}ms"))
    
    # 8. Event Readiness Agent
    t7 = datetime.datetime.now()
    readiness_results = readiness_agent.calculate_readiness("evt-001", state)
    state.setdefault("readiness", {})["evt-001"] = readiness_results
    ms7 = int((datetime.datetime.now() - t7).total_seconds() * 1000)
    agent_logs.append(log_agent_run("Event Readiness Agent", readiness_results["summary"], "Completed", f"{ms7}ms"))
    
    add_notification(
        "Multi-Agent Plan Generated",
        f"8 AI Agents collaborated to synthesize complete operational plan for {spec['eventType']} (Readiness: {readiness_results['overallScore']}%).",
        "success",
        "dashboard"
    )

    return jsonify({
        "success": True,
        "specification": spec,
        "venuePlan": venue_results,
        "resourcePlan": resource_results,
        "volunteerPlan": volunteer_results,
        "schedulePlan": schedule_results,
        "conflictPlan": conflict_results,
        "readiness": readiness_results,
        "agentLogs": agent_logs,
        "fullState": state
    })

@app.route('/api/agents/resolve-conflict', methods=['POST'])
def resolve_conflict():
    """Applies an AI-recommended mitigation option to resolve an operational conflict."""
    data = request.get_json() or {}
    conflict_id = data.get("conflictId")
    option_id = data.get("optionId", "opt-1")
    
    conflicts = state.get("conflicts", [])
    target = next((c for c in conflicts if c.get("id") == conflict_id), None)
            
    if not target:
        return jsonify({"success": False, "message": f"Conflict {conflict_id} not found"}), 404
        
    chosen_option = next((opt for opt in target.get("options", []) if opt["id"] == option_id), target.get("options", [{}])[0])
    
    target["status"] = "Resolved"
    target["resolvedOption"] = chosen_option
    target["resolvedAt"] = datetime.datetime.now().strftime("%H:%M:%S")
    
    if "Projector" in target.get("title", ""):
        for res in state.get("resources", []):
            if res.get("code") == "PRJ-HD":
                res["status"] = "Optimal"
                res["allocated"] = 6
                res["available"] = 2
                res["notes"] = "Spare unit PRJ-07 dispatched to Seminar Hall B (Conflict Resolved)"
                
    if "Volunteer" in target.get("title", ""):
        for vol in state.get("volunteers", []):
            if "Aarav" in vol.get("name", ""):
                vol["workload"] = "75%"
            if "Meera" in vol.get("name", ""):
                vol["assignedTasksCount"] = 3
                vol["notes"] = "Assigned Lab 1 LAN testing (Mitigation Applied)"

    calc_readiness = readiness_agent.calculate_readiness("evt-001", state)
    state.setdefault("readiness", {})["evt-001"] = calc_readiness
    
    log_agent_run(
        "Conflict Detection Agent",
        f"Resolved conflict '{target['title']}' using '{chosen_option.get('title', 'Option')}'. Readiness elevated to {calc_readiness['overallScore']}%.",
        "Completed",
        "150ms"
    )
    
    add_notification(
        "Conflict Resolved",
        f"Conflict '{target['title']}' resolved with '{chosen_option.get('title')}'. Readiness: {calc_readiness['overallScore']}%.",
        "success",
        "conflicts"
    )
    
    repo.persist_to_disk()
    return jsonify({
        "success": True,
        "message": f"Conflict {conflict_id} resolved successfully",
        "conflict": target,
        "readiness": calc_readiness,
        "fullState": state
    })

@app.route('/api/agents/replan', methods=['POST'])
def legacy_dynamic_replan():
    """Simulates a real-time disturbance and triggers cascade replanning across all agents."""
    data = request.get_json() or {}
    scenario_type = data.get("scenario", "venue_unavailable")
    
    replan_ag = DynamicReplanningAgent(state)
    simulation = replan_ag.simulate_scenario(scenario_type, "evt-001")
    
    if scenario_type == "venue_unavailable":
        for v in state.get("venues", []):
            if v.get("name") == "Main Auditorium":
                v["status"] = "Busy / Maintenance"
                v["currentBooking"] = "HVAC Maintenance Emergency"
            if v.get("name") == "Innovation Lab":
                v["currentBooking"] = "AI Hackathon Keynote (Rerouted)"
    elif scenario_type == "projector_fails":
        for res in state.get("resources", []):
            if res.get("code") == "PRJ-HD":
                res["notes"] = "Unit PRJ-04 swapped with Laser Unit PRJ-07"
        for c in state.get("conflicts", []):
            if "PRJ-04" in c.get("title", ""):
                c["status"] = "Resolved"
    elif scenario_type == "volunteer_cancels":
        for vol in state.get("volunteers", []):
            if "Aarav" in vol.get("name", ""):
                vol["status"] = "Unavailable"
            if "Meera" in vol.get("name", ""):
                vol["role"] = "Technical Lead & Stage Management (Promoted)"
                vol["workload"] = "85%"

    calc_readiness = readiness_agent.calculate_readiness("evt-001", state)
    state.setdefault("readiness", {})["evt-001"] = calc_readiness

    for step in simulation.get("agentSteps", []):
        log_agent_run(step["agent"], step["action"], "Completed", "190ms")

    add_notification(
        f"Dynamic Replan: {simulation['title']}",
        f"AI Mesh recalculated operational plan. New readiness: {simulation['after']['readiness']}.",
        "alert" if simulation.get("severity") == "Critical" else "warning",
        "dashboard"
    )

    repo.persist_to_disk()
    return jsonify({
        "success": True,
        "simulation": simulation,
        "readiness": calc_readiness,
        "fullState": state
    })

@app.route('/api/approvals/action', methods=['POST'])
def handle_approval():
    """Human-in-the-Loop: Approves, rejects, or requests changes for sensitive permissions."""
    data = request.get_json() or {}
    approval_id = data.get("approvalId")
    action = data.get("action", "approve")
    comments = data.get("comments", "")
    actor_role = data.get("role", "Chief Security Officer / Dean")

    approvals = state.get("approvals", [])
    target = next((a for a in approvals if a.get("id") == approval_id), None)

    if not target:
        return jsonify({"success": False, "message": f"Approval {approval_id} not found"}), 404

    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    if action == "approve":
        target["status"] = "Approved"
        action_desc = f"Approved by {actor_role}"
        n_type = "success"
    elif action == "reject":
        target["status"] = "Rejected"
        action_desc = f"Rejected by {actor_role}: {comments}"
        n_type = "alert"
    else:
        target["status"] = "Changes Requested"
        action_desc = f"Changes requested by {actor_role}: {comments}"
        n_type = "warning"

    target.setdefault("auditTrail", []).append({
        "timestamp": now_str,
        "action": action_desc,
        "actor": actor_role
    })

    for t in state.get("tasks", []):
        if "Permit" in t.get("title", "") or "Overnight" in t.get("title", "") or "Security" in t.get("title", ""):
            if action == "approve":
                t["status"] = "Completed"

    calc_readiness = readiness_agent.calculate_readiness("evt-001", state)
    state.setdefault("readiness", {})["evt-001"] = calc_readiness

    log_agent_run(
        "Human-in-the-Loop Approval Gate",
        f"{action.capitalize()} decision recorded for '{target['title']}' by {actor_role}. Readiness now at {calc_readiness['overallScore']}%.",
        "Completed",
        "110ms"
    )

    add_notification(
        f"Approval {target['status']}",
        f"'{target['title']}' was {target['status'].lower()} by {actor_role}.",
        n_type,
        "approvals"
    )

    repo.persist_to_disk()
    return jsonify({
        "success": True,
        "approval": target,
        "readiness": calc_readiness,
        "fullState": state
    })

@app.route('/api/tasks/toggle', methods=['POST'])
def toggle_task():
    """Toggles task status between Not Started -> In Progress -> Completed."""
    data = request.get_json() or {}
    task_id = data.get("taskId")
    
    tasks = state.get("tasks", [])
    target = next((t for t in tasks if t.get("id") == task_id), None)
            
    if not target:
        return jsonify({"success": False, "message": f"Task {task_id} not found"}), 404
        
    order = ["Not Started", "In Progress", "Completed"]
    curr_idx = order.index(target.get("status", "Not Started")) if target.get("status") in order else 0
    next_status = order[(curr_idx + 1) % len(order)]
    target["status"] = next_status
    
    calc_readiness = readiness_agent.calculate_readiness("evt-001", state)
    state.setdefault("readiness", {})["evt-001"] = calc_readiness
    
    log_agent_run(
        "Task Coordination Agent",
        f"Task '{target['title']}' status transitioned to '{next_status}'.",
        "Completed",
        "95ms"
    )
    
    repo.persist_to_disk()
    return jsonify({
        "success": True,
        "task": target,
        "readiness": calc_readiness,
        "fullState": state
    })

@app.route('/api/tasks/create', methods=['POST'])
def create_task():
    """Creates a new operational task."""
    data = request.get_json() or {}
    new_task = {
        "id": f"tsk-{int(datetime.datetime.now().timestamp() * 1000)}",
        "eventId": data.get("eventId", "evt-001"),
        "title": data.get("title", "New Operational Task"),
        "category": data.get("category", "General"),
        "assignee": data.get("assignee", "Unassigned"),
        "priority": data.get("priority", "Medium"),
        "deadline": data.get("deadline", "2026-09-12 10:00"),
        "status": "Not Started",
        "aiRecommendation": data.get("aiRecommendation", "Coordinated via CampusFlow AI")
    }
    state.setdefault("tasks", []).insert(0, new_task)
    
    log_agent_run(
        "Task Coordination Agent",
        f"Generated new task '{new_task['title']}' assigned to {new_task['assignee']}.",
        "Completed",
        "120ms"
    )
    
    repo.persist_to_disk()
    return jsonify({
        "success": True,
        "task": new_task,
        "fullState": state
    })

@app.route('/api/briefings', methods=['GET'])
def get_briefings():
    """Generates stakeholder briefings for Organizer, Volunteers, Security, and Tech Team."""
    current_evt = get_current_event()
    briefings = briefing_agent.generate_briefings(current_evt, state)
    return jsonify({
        "success": True,
        "briefings": briefings
    })

@app.route('/api/reset', methods=['POST'])
def reset_data():
    """Resets in-memory state back to the original realistic seed data."""
    global state
    state = repo.reset_to_seed()
    calc_readiness = readiness_agent.calculate_readiness("evt-001", state)
    state.setdefault("readiness", {})["evt-001"] = calc_readiness
    
    log_agent_run(
        "CampusFlow AI System",
        "Reset workspace data to initial seed baseline.",
        "Completed",
        "80ms"
    )
    
    add_notification(
        "System State Reset",
        "CampusFlow AI working memory restored to baseline configuration.",
        "info",
        "dashboard"
    )
    
    return jsonify({
        "success": True,
        "message": "Data successfully reset to initial seed state",
        "fullState": state
    })

if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    port = int(os.environ.get('PORT', 5000))
    logger.info(f">> CampusFlow AI Server launching on http://localhost:{port}")
    app.run(host='0.0.0.0', port=port, debug=False)
