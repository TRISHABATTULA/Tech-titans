/**
 * CampusFlow AI — Interactive Client Application
 * Autonomous Multi-Agent Campus Event Operations & Coordination
 */

// Global State Store
let appState = null;
let currentTab = 'tab-overview';
let activeEventId = 'evt-001';
let currentRole = 'Event Organizer';
let currentScheduleDay = 1;
let currentBriefingPersona = 'organizer';
let briefingsData = null;

// Demo Walkthrough Controller State
let demoActive = false;
let demoStep = 0;
let demoTimer = null;
let demoAutoPlay = true;

const DEMO_STEPS = [
  {
    step: 1,
    title: "1. Natural Language Event Intake",
    tab: "tab-intake",
    desc: "The organizer inputs conversational requirements for a 2-day AI Hackathon for 150 students with overnight access.",
    action: "Event Planner Agent parsing multi-day parameters...",
    run: async () => {
      document.getElementById('nl-prompt-input').value = "I want to organize a 2-day AI Hackathon for 150 students on September 12 and 13. We need the main auditorium, 2 computer labs, 6 laser projectors, Wi-Fi 6 mesh, 20 mentors, midnight pizza catering, and overnight security access.";
      await analyzeRequirements();
    }
  },
  {
    step: 2,
    title: "2. Autonomous Multi-Agent Plan Generation",
    tab: "tab-agent-mesh",
    desc: "Watch 8 specialized agents collaborate in sequence: Venue, Resource, Volunteer, Schedule, Conflict, Task, and Readiness agents.",
    action: "Orchestrating multi-agent collaboration cascade...",
    run: async () => {
      await generateFullPlan();
    }
  },
  {
    step: 3,
    title: "3. Spatial Matching & Venue Allocation",
    tab: "tab-venues",
    desc: "Venue Agent analyzed 7 campus spaces and locked Main Auditorium (Cap: 350) + Computer Labs 1 & 2 for breakout tracks.",
    action: "Venue Agent verified room capacities & acoustics.",
    run: async () => {
      // highlighted venues
    }
  },
  {
    step: 4,
    title: "4. Hardware Allocation & Inventory Check",
    tab: "tab-resources",
    desc: "Resource Agent allocated 10 equipment streams. It detected 1 projector shortage (PRJ-04 collision).",
    action: "Resource Agent surfaced laser projector PRJ-04 conflict.",
    run: async () => {
      // highlighted resources
    }
  },
  {
    step: 5,
    title: "5. Volunteer Matching by Skill Matrix",
    tab: "tab-volunteers",
    desc: "Volunteer Agent matched 12 student leads across 7 operational stations (AV, Registration, Hospitality, Security, Help Desk).",
    action: "Volunteer Agent optimized duty shifts with 0 clashes.",
    run: async () => {
      // highlighted volunteers
    }
  },
  {
    step: 6,
    title: "6. Chronological Schedule Synthesis",
    tab: "tab-schedules",
    desc: "Schedule Agent synthesized 15 timeline blocks across Day 1 & Day 2 with keynote, hacking sprints, workshops, and meals.",
    action: "Schedule Agent generated structured timeline.",
    run: async () => {
      // view timeline
    }
  },
  {
    step: 7,
    title: "7. Conflict Detection & Mitigation Options",
    tab: "tab-conflicts",
    desc: "Conflict Detection Agent surfaced 2 operational collisions and formulated 3 ranked AI recommendations.",
    action: "Applying recommended mitigation: Reassign spare Laser Projector PRJ-07...",
    run: async () => {
      // Auto-resolve projector conflict
      await resolveConflict('cnf-001', 'opt-1');
    }
  },
  {
    step: 8,
    title: "8. Human-in-the-Loop Approval Gate",
    tab: "tab-approvals",
    desc: "Security-sensitive actions require human clearance. Chief Security Officer & Dean review the Overnight Access permit.",
    action: "Authorizing Overnight Campus Access permit...",
    run: async () => {
      await handleApprovalAction('app-001', 'approve');
    }
  },
  {
    step: 9,
    title: "9. Dynamic 'What-If' Replanning Simulation",
    tab: "tab-replanning",
    desc: "Simulate a live disruption: Main Auditorium HVAC fails. Watch the AI mesh reroute the keynote and recalculate readiness.",
    action: "Simulating Main Auditorium HVAC failure...",
    run: async () => {
      await simulateScenario('venue_unavailable');
    }
  },
  {
    step: 10,
    title: "10. Readiness Score & Persona Briefings",
    tab: "tab-readiness",
    desc: "Event Readiness elevates to 91%+. AI generated tailored operational run-sheets for Organizers, Volunteers, Security, and AV Crew.",
    action: "Complete AI operations blueprint delivered!",
    run: async () => {
      showToast("Demo Completed! All 10 multi-agent steps verified.", "success");
    }
  }
];

// Presets for Natural Language Intake
const SAMPLE_PROMPTS = {
  hackathon: "I want to organize a 2-day AI Hackathon for 150 students on September 12 and 13. We need the main auditorium, 2 computer labs, 6 laser projectors, Wi-Fi 6 mesh, 20 mentors, midnight pizza catering, and overnight security access.",
  techfest: "Conduct our Annual Technical Fest 2026 for 500 participants on October 5-6 with robotics arena, coding sprints, open ground exhibits, 10kW stage sound rig, and external sponsor stalls.",
  placement: "Organize the Autumn Campus Placement Drive 2026 on September 20 for 300 graduating candidates. Need Seminar Hall A, 2 computer testing labs, 12 silent interview booths, company lounge catering, and biometric attendance.",
  workshop: "Conduct a 1-day Hands-on Robotics and Autonomous Systems Workshop for 60 participants on September 12 in the Innovation Lab with soldering stations, high-amp power strips, and robot kits."
};

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', async () => {
  setupEventListeners();
  await fetchState();
  renderAllViews();
});

async function fetchState() {
  try {
    const res = await fetch('/api/state');
    const json = await res.json();
    if (json.success) {
      appState = json.data;
    }
  } catch (err) {
    console.error("Failed to fetch state:", err);
    showToast("Server connection error. Ensure Flask server is running.", "alert");
  }
}

// ==================== EVENT LISTENERS ====================
function setupEventListeners() {
  // Navigation between Landing & Dashboard
  document.getElementById('enter-app-btn')?.addEventListener('click', () => showView('dashboard'));
  document.getElementById('hero-start-btn')?.addEventListener('click', () => {
    showView('dashboard');
    switchTab('tab-intake');
  });
  document.getElementById('footer-dashboard-btn')?.addEventListener('click', () => showView('dashboard'));
  document.getElementById('header-brand-btn')?.addEventListener('click', () => showView('dashboard'));
  document.getElementById('back-to-landing-btn')?.addEventListener('click', () => showView('landing'));

  // Sidebar Tab Navigation
  document.querySelectorAll('.sidebar-nav .nav-item').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tabId = btn.getAttribute('data-tab');
      if (tabId) switchTab(tabId);
    });
  });

  // Role Switcher
  document.getElementById('user-role-select')?.addEventListener('change', (e) => {
    currentRole = e.target.value;
    showToast(`Active User Role switched to: ${currentRole}`, "info");
    renderApprovals();
  });

  // Event Selector
  document.getElementById('event-select')?.addEventListener('change', (e) => {
    activeEventId = e.target.value;
    showToast(`Active Event switched to: ${e.target.selectedOptions[0].text}`, "info");
    renderAllViews();
  });

  // Notifications Bell
  const bellBtn = document.getElementById('notif-bell-btn');
  const notifDropdown = document.getElementById('notif-dropdown');
  bellBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    notifDropdown?.classList.toggle('hidden');
  });
  document.addEventListener('click', (e) => {
    if (!notifDropdown?.contains(e.target) && e.target !== bellBtn) {
      notifDropdown?.classList.add('hidden');
    }
  });
  document.getElementById('mark-all-read-btn')?.addEventListener('click', () => {
    if (appState && appState.notifications) {
      appState.notifications.forEach(n => n.read = true);
      renderNotifications();
      showToast("All notifications marked as read", "info");
    }
  });

  // Reset Data Button
  document.getElementById('reset-data-btn')?.addEventListener('click', resetBaselineData);

  // Natural Language Intake Presets
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const presetKey = btn.getAttribute('data-preset');
      const promptInput = document.getElementById('nl-prompt-input');
      if (promptInput && SAMPLE_PROMPTS[presetKey]) {
        promptInput.value = SAMPLE_PROMPTS[presetKey];
        showToast(`Loaded ${presetKey.toUpperCase()} scenario prompt`, "info");
      }
    });
  });

  // Intake Action Buttons
  document.getElementById('analyze-prompt-btn')?.addEventListener('click', analyzeRequirements);
  document.getElementById('generate-full-plan-btn')?.addEventListener('click', generateFullPlan);
  document.getElementById('trigger-mesh-orchestration')?.addEventListener('click', generateFullPlan);

  // Dynamic Replanning Scenario Buttons
  document.querySelectorAll('.scenario-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const scenario = btn.getAttribute('data-scenario');
      if (scenario) simulateScenario(scenario);
    });
  });

  // Schedule Day Tabs
  document.querySelectorAll('.sched-day-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.sched-day-btn').forEach(b => {
        b.classList.remove('btn-primary', 'active');
        b.classList.add('btn-outline');
      });
      btn.classList.add('btn-primary', 'active');
      btn.classList.remove('btn-outline');
      currentScheduleDay = parseInt(btn.getAttribute('data-day') || '1');
      renderSchedule();
    });
  });

  // Briefing Persona Tabs
  document.querySelectorAll('.briefing-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.briefing-tab-btn').forEach(b => {
        b.classList.remove('btn-primary', 'active');
        b.classList.add('btn-outline');
      });
      btn.classList.add('btn-primary', 'active');
      btn.classList.remove('btn-outline');
      currentBriefingPersona = btn.getAttribute('data-persona') || 'organizer';
      renderBriefingContent();
    });
  });
  document.getElementById('copy-briefing-btn')?.addEventListener('click', copyBriefingToClipboard);
  document.getElementById('export-briefing-btn')?.addEventListener('click', exportBriefing);

  // Task Filter Buttons
  document.querySelectorAll('.task-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.task-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.getAttribute('data-filter') || 'all';
      renderTasks(filter);
    });
  });

  // Task Modal Dispatch
  document.getElementById('add-new-task-btn')?.addEventListener('click', () => {
    document.getElementById('create-task-modal')?.classList.remove('hidden');
  });
  document.getElementById('close-task-modal-btn')?.addEventListener('click', () => {
    document.getElementById('create-task-modal')?.classList.add('hidden');
  });
  document.getElementById('cancel-task-btn')?.addEventListener('click', () => {
    document.getElementById('create-task-modal')?.classList.add('hidden');
  });
  document.getElementById('new-task-form')?.addEventListener('submit', handleCreateTask);

  // Demo Mode Triggers
  document.getElementById('landing-run-demo-btn')?.addEventListener('click', startDemoMode);
  document.getElementById('hero-demo-btn')?.addEventListener('click', startDemoMode);
  document.getElementById('nav-run-demo-btn')?.addEventListener('click', startDemoMode);
  document.getElementById('close-demo-btn')?.addEventListener('click', stopDemoMode);
  document.getElementById('demo-next-btn')?.addEventListener('click', nextDemoStep);
  document.getElementById('demo-prev-btn')?.addEventListener('click', prevDemoStep);
  document.getElementById('demo-auto-toggle')?.addEventListener('click', toggleDemoAutoPlay);
}

// ==================== VIEW & TAB SWITCHING ====================
function showView(viewName) {
  const landing = document.getElementById('landing-view');
  const dashboard = document.getElementById('dashboard-view');
  if (viewName === 'dashboard') {
    landing?.classList.add('hidden');
    dashboard?.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else {
    dashboard?.classList.add('hidden');
    landing?.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

function switchTab(tabId) {
  currentTab = tabId;
  document.querySelectorAll('.content-tab').forEach(tab => tab.classList.remove('active'));
  document.getElementById(tabId)?.classList.add('active');

  document.querySelectorAll('.sidebar-nav .nav-item').forEach(item => {
    if (item.getAttribute('data-tab') === tabId) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });

  if (tabId === 'tab-briefings') {
    fetchBriefings();
  }
}

// ==================== RENDER ALL VIEWS ====================
function renderAllViews() {
  if (!appState) return;
  renderOverview();
  renderAgentNodes();
  renderAgentLogs();
  renderVenues();
  renderResources();
  renderVolunteers();
  renderSchedule();
  renderConflicts();
  renderTasks();
  renderReadiness();
  renderApprovals();
  renderNotifications();
}

// ==================== 1. OVERVIEW DASHBOARD ====================
function renderOverview() {
  const events = appState.events || [];
  const currEvent = events.find(e => e.id === activeEventId) || events[0] || {};
  const readiness = (appState.readiness && appState.readiness[currEvent.id]) || { overallScore: 87 };

  // Banner details
  document.getElementById('overview-evt-type').textContent = currEvent.type || 'Hackathon';
  document.getElementById('overview-evt-status').textContent = currEvent.status || 'In Planning';
  document.getElementById('overview-evt-date').textContent = currEvent.date || 'Sep 12 - 13, 2026';
  document.getElementById('overview-evt-title').textContent = currEvent.title || 'AI Hackathon 2026';
  document.getElementById('overview-evt-desc').textContent = currEvent.description || '';
  document.getElementById('overview-evt-venue').textContent = currEvent.primaryVenue || 'Main Auditorium';

  // Readiness circle
  const score = readiness.overallScore || 87;
  document.getElementById('overview-readiness-pct').textContent = `${score}%`;
  document.getElementById('overview-gauge-path').setAttribute('stroke-dasharray', `${score}, 100`);
  document.getElementById('kpi-readiness').textContent = `${score}%`;
  document.getElementById('nav-readiness-badge').textContent = `${score}%`;
  document.getElementById('sidebar-readiness-bar').style.width = `${score}%`;

  // KPI numbers
  document.getElementById('kpi-events').textContent = events.length;
  const tasks = appState.tasks || [];
  document.getElementById('kpi-tasks').textContent = tasks.length;
  const inProg = tasks.filter(t => t.status === 'In Progress').length;
  document.getElementById('kpi-tasks-progress').textContent = `${inProg} In Progress`;

  const pendingApprovals = (appState.approvals || []).filter(a => a.status === 'Pending Human Approval');
  document.getElementById('kpi-approvals').textContent = pendingApprovals.length;
  document.getElementById('nav-approvals-count').textContent = `${pendingApprovals.length} Pending`;

  const unresolvedConflicts = (appState.conflicts || []).filter(c => c.status === 'Unresolved');
  document.getElementById('kpi-conflicts').textContent = unresolvedConflicts.length;
  document.getElementById('nav-conflicts-count').textContent = unresolvedConflicts.length;

  const volunteers = appState.volunteers || [];
  document.getElementById('kpi-volunteers').textContent = volunteers.length;
  document.getElementById('nav-vol-count').textContent = volunteers.length;
  document.getElementById('nav-venues-count').textContent = (appState.venues || []).length;

  // Overview Conflicts Preview
  const conflictPreviewContainer = document.getElementById('overview-conflicts-preview');
  if (conflictPreviewContainer) {
    conflictPreviewContainer.innerHTML = (appState.conflicts || []).slice(0, 2).map(c => `
      <div class="conflict-preview-item ${c.status === 'Resolved' ? 'resolved' : ''}">
        <i class="fa-solid ${c.status === 'Resolved' ? 'fa-circle-check text-emerald' : 'fa-triangle-exclamation text-amber'} mt-1"></i>
        <div>
          <div class="font-bold text-sm ${c.status === 'Resolved' ? 'text-emerald' : 'text-amber'}">${c.title}</div>
          <div class="text-xs text-muted">${c.impact}</div>
        </div>
      </div>
    `).join('');
  }

  // Overview Agent Activity Feed
  const agentLogContainer = document.getElementById('overview-agent-log');
  if (agentLogContainer) {
    agentLogContainer.innerHTML = (appState.agentRuns || []).slice(0, 5).map(r => `
      <div class="activity-feed-item">
        <span class="activity-time">${r.timestamp}</span>
        <span class="activity-agent">${r.agent}:</span>
        <span class="activity-text">${r.action}</span>
      </div>
    `).join('');
  }
}

// ==================== 2. NATURAL LANGUAGE INTAKE ====================
async function analyzeRequirements() {
  const promptText = document.getElementById('nl-prompt-input')?.value.trim();
  if (!promptText) {
    showToast("Please enter or select an event prompt to analyze", "warning");
    return;
  }

  showToast("Event Planner Agent parsing requirements...", "info");
  const analyzeBtn = document.getElementById('analyze-prompt-btn');
  if (analyzeBtn) {
    analyzeBtn.disabled = true;
    analyzeBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Analyzing...`;
  }

  try {
    const res = await fetch('/api/agents/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: promptText })
    });
    const json = await res.json();
    if (json.success && json.specification) {
      const spec = json.specification;
      document.getElementById('analysis-reasoning-text').innerHTML = spec.reasoning;
      document.getElementById('ext-type').textContent = spec.eventType;
      document.getElementById('ext-dates').textContent = `${spec.dates} (${spec.duration})`;
      document.getElementById('ext-participants').textContent = `${spec.participants} Attendees`;
      document.getElementById('ext-overnight').textContent = spec.isOvernight ? 'Yes (24/7 Clearance Flagged)' : 'No (Standard Daytime)';

      document.getElementById('ext-venues-tags').innerHTML = (spec.venues || []).map(v => `<span class="tag">${v}</span>`).join('');
      document.getElementById('ext-equip-tags').innerHTML = (spec.equipment || []).map(e => `<span class="tag">${e}</span>`).join('');
      document.getElementById('ext-staff-tags').innerHTML = (spec.staffing || []).map(s => `<span class="tag">${s}</span>`).join('');
      document.getElementById('ext-sec-tags').innerHTML = (spec.security || []).map(sc => `<span class="tag tag-warning">${sc}</span>`).join('');

      showToast("Requirements successfully extracted by Event Planner Agent!", "success");
      await fetchState();
      renderOverview();
      renderAgentLogs();
    }
  } catch (err) {
    console.error("Analysis error:", err);
    showToast("Failed to analyze requirements", "alert");
  } finally {
    if (analyzeBtn) {
      analyzeBtn.disabled = false;
      analyzeBtn.innerHTML = `<i class="fa-solid fa-magnifying-glass-chart"></i> Analyze Requirements`;
    }
  }
}

async function generateFullPlan() {
  const promptText = document.getElementById('nl-prompt-input')?.value.trim() || 
    "I want to organize a 2-day AI Hackathon for 150 students with auditorium, computer labs, projectors, and overnight access.";

  showToast("Multi-Agent Mesh activated! Orchestrating 8 agents...", "info");
  const planBtn = document.getElementById('generate-full-plan-btn');
  if (planBtn) {
    planBtn.disabled = true;
    planBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Synthesizing Full Plan...`;
  }

  try {
    const res = await fetch('/api/agents/generate-plan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: promptText })
    });
    const json = await res.json();
    if (json.success) {
      appState = json.fullState;
      renderAllViews();
      showToast(`Complete Operational Plan generated! Readiness: ${json.readiness.overallScore}%`, "success");
      switchTab('tab-agent-mesh');
    }
  } catch (err) {
    console.error("Plan generation error:", err);
    showToast("Failed to generate plan", "alert");
  } finally {
    if (planBtn) {
      planBtn.disabled = false;
      planBtn.innerHTML = `<i class="fa-solid fa-wand-magic-sparkles"></i> Generate Full Operational Plan`;
    }
  }
}

// ==================== 3. AGENT CONTROL CENTER ====================
const AGENTS_META = [
  { name: "Event Planner Agent", role: "Requirement Parsing & Blueprint Architect", icon: "fa-brain", color: "text-cyan", bg: "bg-cyan" },
  { name: "Venue Agent", role: "Capacity Matching & Spatial Allocation", icon: "fa-building-columns", color: "text-blue", bg: "bg-blue" },
  { name: "Resource Agent", role: "Hardware Allocation & Shortage Diagnostics", icon: "fa-microchip", color: "text-purple", bg: "bg-purple" },
  { name: "Volunteer Agent", role: "Skill Matrix & Duty Station Roster", icon: "fa-users-gear", color: "text-rose", bg: "bg-rose" },
  { name: "Schedule Agent", role: "Chronological Timeline & Milestone Synthesis", icon: "fa-calendar-check", color: "text-amber", bg: "bg-amber" },
  { name: "Conflict Detection Agent", role: "Cross-Domain Constraint Verification", icon: "fa-shield-halved", color: "text-amber", bg: "bg-amber" },
  { name: "Task Coordination Agent", role: "Work Order Dispatch & Prioritization", icon: "fa-list-check", color: "text-blue", bg: "bg-blue" },
  { name: "Event Readiness Agent", role: "7-Dimension Launch Index & Diagnosis", icon: "fa-chart-pie", color: "text-emerald", bg: "bg-emerald" }
];

function renderAgentNodes() {
  const container = document.getElementById('agent-nodes-container');
  if (!container) return;

  container.innerHTML = AGENTS_META.map(ag => `
    <div class="agent-node-card active-pulse">
      <div class="node-top">
        <div class="node-icon ${ag.bg}"><i class="fa-solid ${ag.icon}"></i></div>
        <span class="badge badge-success"><i class="fa-solid fa-circle-check"></i> Synced</span>
      </div>
      <div class="node-title">${ag.name}</div>
      <div class="node-role">${ag.role}</div>
      <div class="node-footer">
        <span class="text-muted"><i class="fa-solid fa-bolt"></i> Autonomous</span>
        <span class="font-mono text-cyan">Active</span>
      </div>
    </div>
  `).join('');
}

function renderAgentLogs() {
  const tbody = document.getElementById('agent-runs-table-body');
  if (!tbody || !appState) return;

  tbody.innerHTML = (appState.agentRuns || []).map(r => `
    <tr>
      <td class="font-mono text-dim text-xs">${r.timestamp}</td>
      <td class="font-bold text-cyan">${r.agent}</td>
      <td class="text-muted">${r.action}</td>
      <td class="font-mono text-xs">${r.duration || '210ms'}</td>
      <td>
        <span class="badge ${r.status === 'Completed' ? 'badge-success' : 'badge-warning'}">
          ${r.status}
        </span>
      </td>
    </tr>
  `).join('');
}

// ==================== 4. VENUES ====================
function renderVenues() {
  const container = document.getElementById('venues-card-container');
  if (!container || !appState) return;

  container.innerHTML = (appState.venues || []).map(v => {
    const isAvail = v.status === 'Available';
    return `
      <div class="venue-card">
        <div class="venue-card-header">
          <div>
            <div class="venue-name">${v.name}</div>
            <div class="venue-bldg"><i class="fa-solid fa-map-pin text-cyan"></i> ${v.building}</div>
          </div>
          <span class="badge ${isAvail ? 'badge-success' : 'badge-warning'}">${v.status}</span>
        </div>
        <div class="d-flex justify-between items-center text-sm">
          <span class="text-muted">Seating Capacity:</span>
          <span class="venue-cap-badge text-cyan">${v.capacity} Seats</span>
        </div>
        <div class="text-xs text-dim">
          <strong>Current Booking:</strong> ${v.currentBooking}
        </div>
        <div class="tag-cloud mt-2">
          ${(v.facilities || []).map(f => `<span class="tag">${f}</span>`).join('')}
        </div>
      </div>
    `;
  }).join('');
}

// ==================== 5. RESOURCES ====================
function renderResources() {
  const container = document.getElementById('resources-card-container');
  if (!container || !appState) return;

  container.innerHTML = (appState.resources || []).map(r => {
    const isShortage = r.status === 'Warning';
    const fillPct = Math.min(100, Math.round((r.allocated / r.total) * 100));
    return `
      <div class="resource-card">
        <div class="d-flex justify-between items-center">
          <span class="badge badge-outline font-mono">${r.code}</span>
          <span class="badge ${isShortage ? 'badge-warning' : 'badge-success'}">${r.status}</span>
        </div>
        <div class="font-bold text-md">${r.name}</div>
        <div class="d-flex justify-between text-xs text-muted">
          <span>Allocated: <strong>${r.allocated} ${r.unit}</strong></span>
          <span>Available: <strong>${r.available} ${r.unit}</strong> / Total ${r.total}</span>
        </div>
        <div class="res-meter-bar">
          <div class="res-meter-fill ${isShortage ? 'warning' : ''}" style="width: ${fillPct}%"></div>
        </div>
        <div class="text-xs text-dim"><i class="fa-solid fa-warehouse"></i> ${r.location} • Health: ${r.health}</div>
        ${r.notes ? `<div class="text-xs ${isShortage ? 'text-amber' : 'text-emerald'} font-semibold mt-1"><i class="fa-solid fa-circle-info"></i> ${r.notes}</div>` : ''}
      </div>
    `;
  }).join('');
}

// ==================== 6. VOLUNTEERS ====================
function renderVolunteers() {
  const container = document.getElementById('volunteers-card-container');
  if (!container || !appState) return;

  container.innerHTML = (appState.volunteers || []).map(vol => `
    <div class="volunteer-card">
      <div class="vol-header">
        <div>
          <div class="vol-name">${vol.name}</div>
          <div class="vol-dept">${vol.department}</div>
        </div>
        <span class="badge ${vol.status === 'Assigned' ? 'badge-primary' : 'badge-outline'}">${vol.status}</span>
      </div>
      <div class="vol-station">
        <i class="fa-solid fa-location-crosshairs text-cyan"></i>
        <span>${vol.role}</span>
      </div>
      <div class="d-flex justify-between text-xs text-dim">
        <span>Workload: <strong class="text-main">${vol.workload}</strong></span>
        <span>Availability: <strong class="text-main">${vol.availability}</strong></span>
      </div>
      <div class="tag-cloud mt-1">
        ${(vol.skills || []).map(s => `<span class="tag">${s}</span>`).join('')}
      </div>
      <div class="d-flex justify-between text-xs text-dim pt-2 border-t border-subtle mt-1">
        <span><i class="fa-solid fa-phone"></i> ${vol.phone}</span>
        <span><i class="fa-solid fa-envelope"></i> ${vol.email.split('@')[0]}</span>
      </div>
    </div>
  `).join('');
}

// ==================== 7. SCHEDULE ====================
function renderSchedule() {
  const container = document.getElementById('timeline-items-container');
  if (!container || !appState) return;

  const schedules = appState.schedules || [];
  const currDayData = schedules.find(s => s.day === currentScheduleDay) || schedules[0] || { items: [] };

  container.innerHTML = (currDayData.items || []).map(item => `
    <div class="timeline-block">
      <div class="timeline-time">${item.time}</div>
      <div class="timeline-content">
        <div class="timeline-title">${item.title}</div>
        <div class="timeline-meta">
          <span><i class="fa-solid fa-location-dot text-cyan"></i> ${item.venue}</span>
          <span><i class="fa-solid fa-user-tie text-purple"></i> Lead: ${item.lead}</span>
        </div>
      </div>
      <span class="badge badge-outline">${item.type}</span>
    </div>
  `).join('');
}

// ==================== 8. CONFLICTS ====================
function renderConflicts() {
  const container = document.getElementById('conflicts-card-container');
  if (!container || !appState) return;

  const conflicts = appState.conflicts || [];
  if (conflicts.length === 0) {
    container.innerHTML = `
      <div class="card p-4 text-center">
        <div class="text-emerald text-3xl mb-2"><i class="fa-solid fa-circle-check"></i></div>
        <h3 class="font-bold text-lg">Zero Active Operational Conflicts</h3>
        <p class="text-muted text-sm">All venue bookings, hardware allocations, and volunteer rosters are 100% clean and verified.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = conflicts.map(c => {
    const isResolved = c.status === 'Resolved';
    return `
      <div class="conflict-card ${isResolved ? 'resolved' : ''}">
        <div class="conflict-header">
          <div>
            <div class="conflict-title ${isResolved ? 'text-emerald' : ''}">
              <i class="fa-solid ${isResolved ? 'fa-circle-check text-emerald' : 'fa-triangle-exclamation'}"></i>
              ${c.title}
            </div>
            <div class="text-xs text-dim font-mono mt-1">ID: ${c.id} • Category: ${c.category} • Severity: ${c.severity}</div>
          </div>
          <span class="badge ${isResolved ? 'badge-success' : 'badge-danger'}">${c.status}</span>
        </div>

        <p class="conflict-desc">${c.description}</p>
        <div class="conflict-impact"><i class="fa-solid fa-circle-exclamation"></i> Impact: ${c.impact}</div>

        ${isResolved ? `
          <div class="alert-banner alert-success mb-2">
            <i class="fa-solid fa-check"></i>
            <div>
              <strong>Mitigation Applied:</strong> ${c.resolvedOption ? c.resolvedOption.title : 'Resolved'}
              <div class="text-xs text-muted">Applied at ${c.resolvedAt || 'Recently'} via Conflict Detection Agent</div>
            </div>
          </div>
        ` : `
          <div class="font-bold text-sm mb-2 text-cyan"><i class="fa-solid fa-wand-magic-sparkles"></i> AI Recommended Mitigation Options:</div>
          <div class="mitigation-options-grid">
            ${(c.options || []).map(opt => `
              <div class="mitigation-opt-card ${opt.recommended ? 'recommended' : ''}">
                <div>
                  <div class="d-flex justify-between items-center mb-1">
                    <span class="opt-title">${opt.title}</span>
                    ${opt.recommended ? '<span class="badge badge-primary text-xs">AI Recommended</span>' : ''}
                  </div>
                  <p class="opt-details">${opt.details}</p>
                </div>
                <div class="d-flex justify-between items-center mt-2 pt-2 border-t border-subtle">
                  <span class="text-xs text-dim">Risk Level: <strong class="text-emerald">${opt.risk || 'Low'}</strong></span>
                  <button class="btn btn-xs btn-primary" onclick="resolveConflict('${c.id}', '${opt.id}')">
                    <i class="fa-solid fa-check"></i> Apply Option
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    `;
  }).join('');
}

async function resolveConflict(conflictId, optionId) {
  showToast(`Resolving conflict ${conflictId}...`, "info");
  try {
    const res = await fetch('/api/agents/resolve-conflict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conflictId, optionId })
    });
    const json = await res.json();
    if (json.success) {
      appState = json.fullState;
      renderAllViews();
      showToast(json.message, "success");
    }
  } catch (err) {
    console.error("Conflict resolve error:", err);
    showToast("Failed to resolve conflict", "alert");
  }
}

// ==================== 9. DYNAMIC REPLANNING ====================
async function simulateScenario(scenarioType) {
  showToast(`Dynamic Replanning Agent simulating '${scenarioType}' disturbance...`, "info");
  try {
    const res = await fetch('/api/agents/replan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ scenario: scenarioType })
    });
    const json = await res.json();
    if (json.success) {
      appState = json.fullState;
      renderAllViews();
      renderReplanResults(json.simulation);
      showToast(`Dynamic Replanning complete! New Readiness: ${json.simulation.after.readiness}`, "success");
    }
  } catch (err) {
    console.error("Replanning error:", err);
    showToast("Failed to simulate scenario", "alert");
  }
}

function renderReplanResults(sim) {
  const container = document.getElementById('replan-result-container');
  if (!container) return;
  container.classList.remove('hidden');

  container.innerHTML = `
    <div class="card p-4 border border-emerald">
      <div class="d-flex justify-between items-center mb-3">
        <div>
          <span class="badge badge-warning mb-1">DISRUPTION RESOLVED</span>
          <h3 class="font-bold text-lg text-emerald">${sim.title}</h3>
          <p class="text-sm text-muted">${sim.trigger}</p>
        </div>
        <span class="badge badge-success text-md font-mono">Readiness: ${sim.after.readiness}</span>
      </div>

      <div class="font-bold text-sm mb-2 text-cyan"><i class="fa-solid fa-network-wired"></i> Cascade Agent Re-orchestration Trail:</div>
      <div class="replan-cascade-steps mb-4">
        ${(sim.agentSteps || []).map(step => `
          <div class="cascade-step-item">
            <div>
              <strong class="text-cyan">${step.agent}:</strong>
              <span class="text-muted ml-1">${step.action}</span>
            </div>
            <span class="badge badge-success">${step.status}</span>
          </div>
        `).join('')}
      </div>

      <div class="diff-matrix-grid">
        <div class="diff-card before">
          <div class="font-bold text-sm text-rose mb-2"><i class="fa-solid fa-clock-rotate-left"></i> Before Disturbance:</div>
          <div class="text-xs text-muted" style="line-height: 1.8;">
            ${Object.entries(sim.before || {}).map(([k, v]) => `<div><strong>${k}:</strong> ${v}</div>`).join('')}
          </div>
        </div>

        <div class="diff-card after">
          <div class="font-bold text-sm text-emerald mb-2"><i class="fa-solid fa-wand-magic-sparkles"></i> AI Re-optimized State (After):</div>
          <div class="text-xs text-main" style="line-height: 1.8;">
            ${Object.entries(sim.after || {}).map(([k, v]) => `<div><strong>${k}:</strong> <span class="text-emerald font-bold">${v}</span></div>`).join('')}
          </div>
        </div>
      </div>

      <div class="alert-banner alert-success mt-3">
        <i class="fa-solid fa-lightbulb"></i>
        <div>
          <strong>AI Executive Contingency Strategy:</strong>
          <p class="text-sm">${sim.recommendation}</p>
        </div>
      </div>
    </div>
  `;
}

// ==================== 10. TASKS ====================
function renderTasks(filter = 'all') {
  const tbody = document.getElementById('tasks-table-body');
  if (!tbody || !appState) return;

  const tasks = appState.tasks || [];
  const filtered = filter === 'all' ? tasks : tasks.filter(t => t.status === filter);
  document.getElementById('task-filter-all-count').textContent = tasks.length;

  tbody.innerHTML = filtered.map(t => {
    let statusBadge = 'badge-outline';
    if (t.status === 'In Progress') statusBadge = 'badge-warning';
    if (t.status === 'Completed') statusBadge = 'badge-success';
    if (t.status === 'Pending Approval') statusBadge = 'badge-danger';

    let prioBadge = 'badge-outline';
    if (t.priority === 'Critical') prioBadge = 'badge-danger';
    if (t.priority === 'High') prioBadge = 'badge-warning';

    return `
      <tr>
        <td>
          <button class="badge ${statusBadge} cursor-pointer" onclick="toggleTaskStatus('${t.id}')" title="Click to cycle status">
            <i class="fa-solid ${t.status === 'Completed' ? 'fa-check' : 'fa-rotate'}"></i> ${t.status}
          </button>
        </td>
        <td class="font-bold text-main">${t.title}</td>
        <td><span class="badge badge-outline">${t.category}</span></td>
        <td class="text-muted font-semibold"><i class="fa-solid fa-user-circle text-cyan"></i> ${t.assignee}</td>
        <td><span class="badge ${prioBadge}">${t.priority}</span></td>
        <td class="font-mono text-xs text-dim">${t.deadline}</td>
        <td class="text-xs text-muted"><i class="fa-solid fa-robot text-purple"></i> ${t.aiRecommendation}</td>
      </tr>
    `;
  }).join('');
}

async function toggleTaskStatus(taskId) {
  try {
    const res = await fetch('/api/tasks/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ taskId })
    });
    const json = await res.json();
    if (json.success) {
      appState = json.fullState;
      renderAllViews();
      showToast(`Task updated to: ${json.task.status}`, "info");
    }
  } catch (err) {
    console.error("Task toggle error:", err);
  }
}

async function handleCreateTask(e) {
  e.preventDefault();
  const title = document.getElementById('task-input-title')?.value;
  const category = document.getElementById('task-input-category')?.value;
  const priority = document.getElementById('task-input-priority')?.value;
  const assignee = document.getElementById('task-input-assignee')?.value;
  const deadline = document.getElementById('task-input-deadline')?.value;
  const aiRec = document.getElementById('task-input-rec')?.value || "Coordinated via CampusFlow AI";

  try {
    const res = await fetch('/api/tasks/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, category, priority, assignee, deadline, aiRecommendation: aiRec })
    });
    const json = await res.json();
    if (json.success) {
      appState = json.fullState;
      renderAllViews();
      document.getElementById('create-task-modal')?.classList.add('hidden');
      document.getElementById('new-task-form')?.reset();
      showToast(`Task '${title}' dispatched!`, "success");
    }
  } catch (err) {
    console.error("Task create error:", err);
    showToast("Failed to create task", "alert");
  }
}

// ==================== 11. READINESS ====================
function renderReadiness() {
  if (!appState) return;
  const readiness = (appState.readiness && appState.readiness[activeEventId]) || { overallScore: 87, categories: {}, blockers: [] };

  const score = readiness.overallScore || 87;
  document.getElementById('readiness-score-text').textContent = `${score}%`;
  document.getElementById('readiness-gauge-circle').setAttribute('stroke-dasharray', `${score}, 100`);
  document.getElementById('readiness-summary-text').textContent = readiness.summary || '';

  const statusBadge = document.getElementById('readiness-status-badge');
  if (statusBadge) {
    if (score >= 95) {
      statusBadge.className = 'badge badge-success';
      statusBadge.textContent = 'Launch Ready (100%)';
    } else if (score >= 80) {
      statusBadge.className = 'badge badge-warning';
      statusBadge.textContent = 'Action Required';
    } else {
      statusBadge.className = 'badge badge-danger';
      statusBadge.textContent = 'Critical Blockers';
    }
  }

  // Pillar bars
  const pillarContainer = document.getElementById('pillar-bars-container');
  if (pillarContainer) {
    const cats = readiness.categories || {
      Venue: 100, Equipment: 80, Volunteers: 90, Security: 75, Communication: 95, Transport: 85, Permissions: 70
    };

    pillarContainer.innerHTML = Object.entries(cats).map(([pillar, val]) => {
      let fillColor = 'bg-cyan';
      if (val >= 90) fillColor = 'bg-emerald';
      else if (val >= 75) fillColor = 'bg-amber';
      else fillColor = 'bg-rose';

      return `
        <div class="pillar-row">
          <div class="pillar-header">
            <span>${pillar}</span>
            <span class="font-mono ${val >= 90 ? 'text-emerald' : (val >= 75 ? 'text-amber' : 'text-rose')}">${val}%</span>
          </div>
          <div class="pillar-bar-bg">
            <div class="pillar-bar-fill" style="width: ${val}%; background-color: var(--${val >= 90 ? 'emerald' : (val >= 75 ? 'amber' : 'rose')});"></div>
          </div>
        </div>
      `;
    }).join('');
  }

  // Blockers
  const blockersContainer = document.getElementById('readiness-blockers-list');
  if (blockersContainer) {
    const blockers = readiness.blockers || [];
    blockersContainer.innerHTML = blockers.map(b => `
      <li><i class="fa-solid fa-triangle-exclamation text-rose"></i> ${b}</li>
    `).join('');
  }
}

// ==================== 12. APPROVALS ====================
function renderApprovals() {
  const container = document.getElementById('approvals-card-container');
  if (!container || !appState) return;

  const approvals = appState.approvals || [];
  container.innerHTML = approvals.map(a => {
    const isApproved = a.status === 'Approved';
    const isPending = a.status === 'Pending Human Approval';

    return `
      <div class="approval-card ${isApproved ? 'approved' : (isPending ? 'pending' : '')}">
        <div class="approval-header">
          <div>
            <div class="approval-title">${a.title}</div>
            <div class="text-xs text-dim font-mono mt-1">Category: ${a.category} • Approver: ${a.approverRole}</div>
          </div>
          <span class="badge ${isApproved ? 'badge-success' : (isPending ? 'badge-danger' : 'badge-warning')}">${a.status}</span>
        </div>

        <p class="approval-details">${a.details}</p>
        <div class="text-xs text-amber font-semibold"><i class="fa-solid fa-circle-exclamation"></i> Impact: ${a.impact}</div>

        <div class="approval-audit">
          <strong>Audit Trail:</strong>
          ${(a.auditTrail || []).map(audit => `<div>• [${audit.timestamp}] ${audit.action} (${audit.actor})</div>`).join('')}
        </div>

        ${isPending ? `
          <div class="approval-actions">
            <button class="btn btn-sm btn-primary" onclick="handleApprovalAction('${a.id}', 'approve')">
              <i class="fa-solid fa-check"></i> Approve Request
            </button>
            <button class="btn btn-sm btn-secondary" onclick="handleApprovalAction('${a.id}', 'request_changes')">
              <i class="fa-solid fa-pen"></i> Request Changes
            </button>
            <button class="btn btn-sm btn-outline text-rose" onclick="handleApprovalAction('${a.id}', 'reject')">
              <i class="fa-solid fa-xmark"></i> Reject
            </button>
          </div>
        ` : `
          <div class="text-xs text-emerald font-bold mt-2"><i class="fa-solid fa-check-double"></i> Decision finalized. Audit signature recorded.</div>
        `}
      </div>
    `;
  }).join('');
}

async function handleApprovalAction(approvalId, action) {
  showToast(`Submitting ${action} for approval ${approvalId}...`, "info");
  try {
    const res = await fetch('/api/approvals/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ approvalId, action, role: currentRole })
    });
    const json = await res.json();
    if (json.success) {
      appState = json.fullState;
      renderAllViews();
      showToast(`Approval ${json.approval.status} successfully by ${currentRole}!`, "success");
    }
  } catch (err) {
    console.error("Approval error:", err);
    showToast("Failed to process approval", "alert");
  }
}

// ==================== 13. BRIEFINGS ====================
async function fetchBriefings() {
  try {
    const res = await fetch('/api/briefings');
    const json = await res.json();
    if (json.success) {
      briefingsData = json.briefings;
      renderBriefingContent();
    }
  } catch (err) {
    console.error("Briefing fetch error:", err);
  }
}

function renderBriefingContent() {
  if (!briefingsData) return;
  const dossier = briefingsData[currentBriefingPersona];
  if (!dossier) return;

  document.getElementById('briefing-title').textContent = dossier.title;
  document.getElementById('briefing-badge').textContent = dossier.badge || 'Dossier';

  let html = `
    <div class="mb-3">
      <div class="font-bold text-sm text-dim">TARGET AUDIENCE: <span class="text-cyan">${dossier.targetPersona}</span></div>
    </div>

    <h4 class="briefing-section-h4"><i class="fa-solid fa-star text-amber"></i> Executive Operational Highlights</h4>
    <ul class="mb-3" style="padding-left: 1.2rem; color: var(--text-muted);">
      ${(dossier.keyHighlights || []).map(h => `<li class="mb-1">${h}</li>`).join('')}
    </ul>
  `;

  if (dossier.criticalActionItems) {
    html += `
      <h4 class="briefing-section-h4"><i class="fa-solid fa-list-check text-cyan"></i> Critical Action Items & Deadlines</h4>
      <ul class="mb-3" style="padding-left: 1.2rem; color: var(--text-muted);">
        ${dossier.criticalActionItems.map(item => `<li class="mb-1">${item}</li>`).join('')}
      </ul>
    `;
  }

  if (dossier.stationRoster) {
    html += `
      <h4 class="briefing-section-h4"><i class="fa-solid fa-users text-purple"></i> Volunteer Duty Stationing Roster</h4>
      <div class="table-responsive mb-3">
        <table class="table-modern">
          <thead><tr><th>Volunteer</th><th>Role</th><th>Assigned Station</th><th>Shift Hours</th></tr></thead>
          <tbody>
            ${dossier.stationRoster.map(s => `<tr><td class="font-bold">${s.name}</td><td>${s.role}</td><td class="text-cyan">${s.station}</td><td class="font-mono text-xs">${s.time}</td></tr>`).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  if (dossier.securityProtocols) {
    html += `
      <h4 class="briefing-section-h4"><i class="fa-solid fa-shield-halved text-rose"></i> Campus Security & Safety Protocols</h4>
      <ul class="mb-3" style="padding-left: 1.2rem; color: var(--text-muted);">
        ${dossier.securityProtocols.map(p => `<li class="mb-1">${p}</li>`).join('')}
      </ul>
    `;
  }

  if (dossier.emergencyContacts) {
    html += `
      <h4 class="briefing-section-h4"><i class="fa-solid fa-phone-volume text-emerald"></i> On-Duty Emergency Contacts</h4>
      <div class="tag-cloud mb-3">
        ${dossier.emergencyContacts.map(c => `<span class="tag"><strong>${c.role}:</strong> ${c.name} (${c.phone})</span>`).join('')}
      </div>
    `;
  }

  if (dossier.setupChecklist) {
    html += `
      <h4 class="briefing-section-h4"><i class="fa-solid fa-wrench text-blue"></i> Technical & Infrastructure Checklist</h4>
      <div class="table-responsive mb-3">
        <table class="table-modern">
          <thead><tr><th>Technical Checklist Item</th><th>Lead Owner</th><th>Status</th></tr></thead>
          <tbody>
            ${dossier.setupChecklist.map(ck => `<tr><td>${ck.item}</td><td class="font-bold">${ck.owner}</td><td><span class="badge ${ck.status === 'Ready' ? 'badge-success' : 'badge-warning'}">${ck.status}</span></td></tr>`).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  document.getElementById('briefing-body-content').innerHTML = html;
}

function copyBriefingToClipboard() {
  const content = document.getElementById('briefing-body-content')?.innerText;
  if (content) {
    navigator.clipboard.writeText(content);
    showToast("Stakeholder briefing copied to clipboard!", "success");
  }
}

function exportBriefing() {
  showToast("Dossier exported to printable PDF/Markdown format", "info");
  window.print();
}

// ==================== 14. NOTIFICATIONS ====================
function renderNotifications() {
  const container = document.getElementById('notif-list');
  const badge = document.getElementById('notif-badge');
  if (!container || !appState) return;

  const notifs = appState.notifications || [];
  const unreadCount = notifs.filter(n => !n.read).length;

  if (badge) {
    badge.textContent = unreadCount;
    badge.style.display = unreadCount > 0 ? 'flex' : 'none';
  }

  container.innerHTML = notifs.map(n => `
    <div class="notif-item ${n.read ? '' : 'unread'}" onclick="handleNotifClick('${n.id}', '${n.targetTab}')">
      <div class="notif-item-title">
        <span>${n.title}</span>
        <span class="notif-time">${n.timestamp}</span>
      </div>
      <div class="notif-msg">${n.message}</div>
    </div>
  `).join('');
}

function handleNotifClick(notifId, targetTab) {
  if (appState && appState.notifications) {
    const notif = appState.notifications.find(n => n.id === notifId);
    if (notif) notif.read = true;
    renderNotifications();
  }
  document.getElementById('notif-dropdown')?.classList.add('hidden');
  if (targetTab) switchTab(`tab-${targetTab}`);
}

// ==================== 15. BASELINE DATA RESET ====================
async function resetBaselineData() {
  showToast("Restoring CampusFlow AI working state to initial baseline...", "info");
  try {
    const res = await fetch('/api/reset', { method: 'POST' });
    const json = await res.json();
    if (json.success) {
      appState = json.fullState;
      renderAllViews();
      showToast("Workspace successfully reset to baseline!", "success");
    }
  } catch (err) {
    console.error("Reset error:", err);
    showToast("Failed to reset data", "alert");
  }
}

// ==================== 16. DEMO MODE ENGINE ====================
function startDemoMode() {
  showView('dashboard');
  demoActive = true;
  demoStep = 0;
  document.getElementById('demo-overlay')?.classList.remove('hidden');
  executeDemoStep();
}

function stopDemoMode() {
  demoActive = false;
  if (demoTimer) clearTimeout(demoTimer);
  document.getElementById('demo-overlay')?.classList.add('hidden');
  showToast("AI Demo Mode stopped.", "info");
}

function toggleDemoAutoPlay() {
  demoAutoPlay = !demoAutoPlay;
  const btn = document.getElementById('demo-auto-toggle');
  if (btn) {
    btn.innerHTML = demoAutoPlay ? `<i class="fa-solid fa-pause"></i> Pause Auto` : `<i class="fa-solid fa-play"></i> Resume Auto`;
  }
}

async function executeDemoStep() {
  if (!demoActive || demoStep >= DEMO_STEPS.length) {
    if (demoStep >= DEMO_STEPS.length) stopDemoMode();
    return;
  }

  const current = DEMO_STEPS[demoStep];
  const total = DEMO_STEPS.length;
  const pct = Math.round(((demoStep + 1) / total) * 100);

  // Update overlay UI
  document.getElementById('demo-progress-fill').style.width = `${pct}%`;
  document.getElementById('demo-step-num').textContent = `Step ${demoStep + 1} of ${total}`;
  document.getElementById('demo-step-title').textContent = current.title;
  document.getElementById('demo-step-desc').textContent = current.desc;
  document.getElementById('demo-action-text').textContent = current.action;
  document.getElementById('demo-prev-btn').disabled = demoStep === 0;

  // Switch tab & run step execution
  switchTab(current.tab);
  if (current.run) {
    await current.run();
  }

  if (demoAutoPlay && demoStep < total - 1) {
    demoTimer = setTimeout(() => {
      if (demoActive && demoAutoPlay) {
        demoStep++;
        executeDemoStep();
      }
    }, 4500);
  }
}

function nextDemoStep() {
  if (demoTimer) clearTimeout(demoTimer);
  if (demoStep < DEMO_STEPS.length - 1) {
    demoStep++;
    executeDemoStep();
  } else {
    stopDemoMode();
  }
}

function prevDemoStep() {
  if (demoTimer) clearTimeout(demoTimer);
  if (demoStep > 0) {
    demoStep--;
    executeDemoStep();
  }
}

// ==================== TOAST NOTIFICATIONS ====================
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  let icon = 'fa-circle-info text-cyan';
  if (type === 'success') icon = 'fa-circle-check text-emerald';
  if (type === 'alert') icon = 'fa-triangle-exclamation text-rose';
  if (type === 'warning') icon = 'fa-circle-exclamation text-amber';

  toast.innerHTML = `
    <i class="fa-solid ${icon}"></i>
    <span>${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(50px)';
    toast.style.transition = 'all 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
