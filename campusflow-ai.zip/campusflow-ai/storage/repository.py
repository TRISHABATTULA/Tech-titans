"""
CampusFlow AI - Storage & Repository Layer
Manages in-memory working state and synchronization with data/campus_data.json.
"""

import os
import json
import copy
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger("Repository")


class EventRepository:
    def __init__(self, data_path: Optional[str] = None):
        if data_path is None:
            self.data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'campus_data.json')
        else:
            self.data_path = data_path
            
        self.state: Dict[str, Any] = self._load_data()
        self.initial_snapshot = copy.deepcopy(self.state)

    def _load_data(self) -> Dict[str, Any]:
        try:
            if os.path.exists(self.data_path):
                with open(self.data_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"[Repository] Error loading data from {self.data_path}: {e}")
        return {
            "events": [],
            "venues": [],
            "resources": [],
            "volunteers": [],
            "tasks": [],
            "schedules": [],
            "conflicts": [],
            "approvals": [],
            "readiness": {},
            "notifications": [],
            "agentRuns": [],
            "eventPlans": {},
            "eventRequirements": {}
        }

    def persist_to_disk(self) -> bool:
        try:
            os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
            with open(self.data_path, 'w', encoding='utf-8') as f:
                json.dump(self.state, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"[Repository] Failed to persist data to {self.data_path}: {e}")
            return False

    def reset_to_seed(self) -> Dict[str, Any]:
        self.state = copy.deepcopy(self.initial_snapshot)
        self.persist_to_disk()
        return self.state

    # --- Event Management ---
    def get_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        for evt in self.state.get("events", []):
            if evt.get("id") == event_id:
                return evt
        return None

    def list_events(self) -> List[Dict[str, Any]]:
        return self.state.get("events", [])

    def save_event(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        events = self.state.setdefault("events", [])
        event_id = event_data.get("id")
        
        existing_idx = next((i for i, e in enumerate(events) if e.get("id") == event_id), None)
        if existing_idx is not None:
            events[existing_idx] = {**events[existing_idx], **event_data}
            saved = events[existing_idx]
        else:
            events.insert(0, event_data)
            saved = event_data
            
        self.persist_to_disk()
        return saved

    # --- Event Plan Management ---
    def save_event_plan(self, event_id: str, plan_data: Dict[str, Any]) -> Dict[str, Any]:
        plans = self.state.setdefault("eventPlans", {})
        plans[event_id] = plan_data
        
        # Also update main event readiness / overview if present
        event = self.get_event(event_id)
        if event:
            if "readinessScore" in plan_data:
                event["readinessScore"] = plan_data["readinessScore"]
            event["status"] = plan_data.get("status", event.get("status", "In Planning"))

        self.persist_to_disk()
        return plan_data

    def get_event_plan(self, event_id: str) -> Optional[Dict[str, Any]]:
        plans = self.state.get("eventPlans", {})
        if event_id in plans:
            return plans[event_id]
        return None

    # --- Event Requirements ---
    def save_event_requirements(self, event_id: str, requirements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        all_reqs = self.state.setdefault("eventRequirements", {})
        all_reqs[event_id] = requirements
        self.persist_to_disk()
        return requirements

    def get_event_requirements(self, event_id: str) -> List[Dict[str, Any]]:
        return self.state.get("eventRequirements", {}).get(event_id, [])

    # --- Tasks Management ---
    def save_tasks(self, event_id: str, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        existing_tasks = self.state.setdefault("tasks", [])
        
        # Filter out old tasks for this event if replacing, or merge
        task_ids = {t["id"] for t in tasks if "id" in t}
        self.state["tasks"] = [t for t in existing_tasks if t.get("id") not in task_ids]
        for t in reversed(tasks):
            self.state["tasks"].insert(0, t)
            
        self.persist_to_disk()
        return tasks

    def get_tasks(self, event_id: Optional[str] = None) -> List[Dict[str, Any]]:
        all_tasks = self.state.get("tasks", [])
        if event_id:
            return [t for t in all_tasks if t.get("eventId") == event_id]
        return all_tasks

    # --- Approvals ---
    def save_approval(self, approval_data: Dict[str, Any]) -> Dict[str, Any]:
        approvals = self.state.setdefault("approvals", [])
        existing_idx = next((i for i, a in enumerate(approvals) if a.get("id") == approval_data.get("id")), None)
        if existing_idx is not None:
            approvals[existing_idx] = approval_data
        else:
            approvals.insert(0, approval_data)
        self.persist_to_disk()
        return approval_data

    def get_approvals(self, event_id: Optional[str] = None) -> List[Dict[str, Any]]:
        all_appr = self.state.get("approvals", [])
        if event_id:
            return [a for a in all_appr if a.get("eventId") == event_id]
        return all_appr

    # --- Agent Runs ---
    def record_agent_run(self, run_data: Dict[str, Any]) -> Dict[str, Any]:
        runs = self.state.setdefault("agentRuns", [])
        runs.insert(0, run_data)
        if len(runs) > 50:
            self.state["agentRuns"] = runs[:50]
        self.persist_to_disk()
        return run_data

    def get_agent_runs(self, event_id: Optional[str] = None) -> List[Dict[str, Any]]:
        all_runs = self.state.get("agentRuns", [])
        if event_id:
            return [r for r in all_runs if r.get("eventId") == event_id or r.get("eventId") is None]
        return all_runs
